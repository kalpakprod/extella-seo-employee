// ожидание: фоновая задача; проверка свежести страницы ограничена тремя секундами.
(() => {
  const PANEL_VERSION='1.0.0';
  const EXPERT_RUN = 'seo_employee_run';
  const EXPERT_STATE = 'seo_employee_state';
  const STATE_VIEWS = ['empty', 'running', 'failed', 'result'];
  const GROUPS = ['new', 'fixed', 'unchanged'];
  const EVIDENCE_TEST_IDS = ['alpha', 'bravo', 'charlie', 'delta', 'echo', 'foxtrot', 'golf', 'hotel', 'india', 'juliet'];
  const el = id => document.getElementById(id);

  const COPY = {
    ru: {
      pageTitle: 'SEO-сотрудник Extella', productLabel: 'Extella · SEO-сотрудник',
      title: 'Проверяй сайт и получай задачи с доказательствами',
      lead: 'Укажи публичный адрес сайта, настрой суточный запуск и начни с первой проверки.',
      settingsLabel: 'Настройки проверки', settingsTitle: 'Сайт и расписание',
      siteUrlLabel: 'Публичный URL сайта', siteUrlPlaceholder: 'https://example.com',
      gscTitle: 'Google Search Console', gscStatus: 'Не настроена, необязательно',
      gscNote: 'Публичная проверка работает без неё. Данные о потерях трафика и позициях недоступны.',
      dailyTimeLabel: 'Время суточной проверки', timezoneLabel: 'Часовой пояс IANA',
      timezonePlaceholder: 'Europe/Berlin', saveSettings: 'Сохранить настройки', savingSettings: 'Сохраняю…',
      scheduleLabel: 'Суточный запуск', scheduleTitle: 'Следующая проверка', scheduleTime: 'Время',
      nextRun: 'Следующий запуск', notScheduled: 'Ещё не рассчитан',
      helpTitle: '? Как это работает',
      helpSources: 'CrawlSEO и SEOmator независимо проверяют публичные страницы. Google Search Console в этом выпуске не подключается.',
      helpLimits: 'SEO-сотрудник не гарантирует позиции, трафик или выручку. Без Search Console он не определяет потери трафика.',
      helpRollback: 'Владелец сайта решает, принимать ли задачу и как откатить изменение. Панель сама сайт не меняет.',
      dataTitle: 'Что потребуется для будущего подключения Search Console',
      dataCategories: 'Категории: адреса страниц, поисковые запросы, показы, клики и позиции.',
      dataLocation: 'Выполнение и хранение: в среде Extella владельца сайта.',
      dataRecipient: 'Получатель входа модели: выбранный владельцем провайдер модели получает только разрешённый минимум по задаче.',
      dataRetention: 'Срок: до удаления подключения владельцем.',
      dataRemoval: 'Удаление: отключение удаляет сохранённый доступ и останавливает новые запросы.',
      dataConsent: 'Подключение начнётся только после отдельного явного согласия. В этом выпуске подключение недоступно.',
      resultLabel: 'Результат проверки', resultTitle: 'Состояние сайта', stateEmpty: 'Проверок нет',
      emptyTitle: 'Проверок ещё нет', emptyText: 'Сохрани адрес и нажми «Проверить сайт». Здесь появятся задачи и доказательства.',
      runningTitle: 'Проверяю публичные страницы', runningText: 'Собираю независимые источники и формирую задачи.',
      runningStatus: 'Проверка уже выполняется. Обновляю состояние…',
      duplicateStatus: 'Такая проверка уже выполняется или завершена. Обновляю состояние…',
      failedTitle: 'Проверку не удалось завершить',
      failedText: 'Проверь публичный адрес и подключение, затем запусти проверку ещё раз.',
      partialTitle: 'Результат неполный', runTime: 'Время проверки', sourceStates: 'Источники',
      newFindings: 'Новые', fixedFindings: 'Исправленные', unchangedFindings: 'Без изменений',
      runAction: 'Проверить сайт', runningAction: 'Проверяю…', readyStatus: 'Готов к проверке.',
      loadingState: 'Получаю последнее состояние…', checkingStatus: 'Проверка началась. Собираю независимые источники.',
      savedStatus: 'Настройки сохранены. Суточный запуск не мешает ручной проверке.',
      readyResultStatus: 'Проверка завершена. Задачи и доказательства готовы.',
      partialResultStatus: 'Проверка завершена частично. Отсутствующие источники перечислены.',
      emptyGroup: 'В этой группе находок нет.', countOnly: 'Количество известно, подробных карточек нет.',
      missingSources: 'Нет данных из источников: ', sourceUnknown: 'Статус не указан',
      severity: 'Серьёзность', url: 'URL', fact: 'Факт', sources: 'Источники',
      businessImpact: 'Деловое последствие', minimalFix: 'Минимальное исправление', verification: 'Как проверить',
      evidence: 'Доказательства', noEvidence: 'Отдельные доказательства не переданы.', unnamedSource: 'Источник не указан',
      invalidUrl: 'Укажи публичный URL с http или https, без локального или приватного адреса.',
      invalidTime: 'Укажи время суточной проверки.', invalidTimezone: 'Укажи действующий часовой пояс IANA, например Europe/Berlin.',
      timeoutError: 'Проверка не ответила вовремя. Проверь подключение к Extella и запусти её ещё раз.',
      unavailableError: 'Extella сейчас не получила результат. Проверь подключение и повтори проверку.',
      invalidUrlError: 'Адрес сайта не принят. Укажи публичный URL и повтори проверку.',
      genericError: 'Проверку не удалось завершить. Проверь адрес и подключение, затем запусти её ещё раз.',
      settingsError: 'Настройки не сохранились. Проверь поля и подключение к Extella, затем повтори.',
      standaloneStatus: 'Открой эту панель внутри Extella, чтобы выполнить проверку.',
      stateReady: 'Готово', statePartial: 'Частично', stateRunning: 'Идёт проверка', stateFailed: 'Нужна проверка',
      sourceOk: 'готов', sourceNotConfigured: 'не настроен', sourceUnavailable: 'недоступен', sourceFailed: 'ошибка',
      severityCritical: 'критично', severityError: 'ошибка', severityWarning: 'предупреждение', severityInfo: 'информация',
    },
    en: {
      pageTitle: 'Extella SEO Employee', productLabel: 'Extella · SEO Employee',
      title: 'Check your site and get evidence-backed tasks',
      lead: 'Enter a public site address, set the daily run, and start with the first check.',
      settingsLabel: 'Check settings', settingsTitle: 'Site and schedule',
      siteUrlLabel: 'Public site URL', siteUrlPlaceholder: 'https://example.com',
      gscTitle: 'Google Search Console', gscStatus: 'Not configured, optional',
      gscNote: 'The public audit works without it. Traffic-loss and ranking data are unavailable.',
      dailyTimeLabel: 'Daily check time', timezoneLabel: 'IANA timezone', timezonePlaceholder: 'Europe/Berlin',
      saveSettings: 'Save settings', savingSettings: 'Saving…',
      scheduleLabel: 'Daily run', scheduleTitle: 'Next check', scheduleTime: 'Time', nextRun: 'Next run',
      notScheduled: 'Not calculated yet', helpTitle: '? How it works',
      helpSources: 'CrawlSEO and SEOmator independently inspect public pages. Google Search Console is not connected in this release.',
      helpLimits: 'The SEO Employee does not guarantee rankings, traffic, or revenue. Without Search Console it cannot determine traffic loss.',
      helpRollback: 'The site owner decides whether to accept a task and how to roll back a change. The panel never changes the site.',
      dataTitle: 'Data required for a future Search Console connection',
      dataCategories: 'Categories: page addresses, search queries, impressions, clicks, and positions.',
      dataLocation: 'Processing and storage: in the site owner’s Extella environment.',
      dataRecipient: 'Model-input recipient: the owner-selected model provider receives only the allowed task minimum.',
      dataRetention: 'Retention: until the owner removes the connection.',
      dataRemoval: 'Removal: disconnecting deletes saved access and stops new requests.',
      dataConsent: 'Connection starts only after separate explicit consent. Connection is unavailable in this release.',
      resultLabel: 'Check result', resultTitle: 'Site status', stateEmpty: 'No checks yet',
      emptyTitle: 'No checks yet', emptyText: 'Save the address and select “Check site”. Tasks and evidence will appear here.',
      runningTitle: 'Checking public pages', runningText: 'Collecting independent sources and preparing tasks.',
      runningStatus: 'A check is already running. Refreshing the state…',
      duplicateStatus: 'This check is already running or has finished. Refreshing the state…',
      failedTitle: 'The check could not finish', failedText: 'Check the public address and connection, then run the check again.',
      partialTitle: 'The result is incomplete', runTime: 'Check time', sourceStates: 'Sources',
      newFindings: 'New', fixedFindings: 'Fixed', unchangedFindings: 'Unchanged',
      runAction: 'Check site', runningAction: 'Checking…', readyStatus: 'Ready to check.',
      loadingState: 'Loading the latest state…', checkingStatus: 'The check started. Collecting independent sources.',
      savedStatus: 'Settings saved. The daily run remains independent from manual checks.',
      readyResultStatus: 'The check finished. Tasks and evidence are ready.',
      partialResultStatus: 'The check finished partially. Missing sources are listed.',
      emptyGroup: 'There are no findings in this group.', countOnly: 'The count is available, but detailed cards are not.',
      missingSources: 'Missing source data: ', sourceUnknown: 'Status not provided',
      severity: 'Severity', url: 'URL', fact: 'Fact', sources: 'Sources', businessImpact: 'Business impact',
      minimalFix: 'Minimum fix', verification: 'How to verify', evidence: 'Evidence',
      noEvidence: 'No separate evidence was provided.', unnamedSource: 'Unnamed source',
      invalidUrl: 'Enter a public URL using http or https, without a local or private address.',
      invalidTime: 'Enter the daily check time.', invalidTimezone: 'Enter a valid IANA timezone, for example Europe/Berlin.',
      timeoutError: 'The check did not answer in time. Check the Extella connection and run it again.',
      unavailableError: 'Extella did not receive a result. Check the connection and run the check again.',
      invalidUrlError: 'The site address was not accepted. Enter a public URL and run the check again.',
      genericError: 'The check could not finish. Check the address and connection, then run it again.',
      settingsError: 'Settings were not saved. Check the fields and Extella connection, then try again.',
      standaloneStatus: 'Open this panel inside Extella to run a check.',
      stateReady: 'Ready', statePartial: 'Partial', stateRunning: 'Checking', stateFailed: 'Needs attention',
      sourceOk: 'ready', sourceNotConfigured: 'not configured', sourceUnavailable: 'unavailable', sourceFailed: 'failed',
      severityCritical: 'critical', severityError: 'error', severityWarning: 'warning', severityInfo: 'information',
    },
  };

  let language = 'ru';
  let bridge = null;
  let currentState = { state: 'empty', config: {}, last_report: null, schedules: [] };
  let runBusy = false;

  function t(key) { return COPY[language][key] || COPY.ru[key] || key; }

  async function healStaleCache() {
    if (!/^https?:$/.test(window.location.protocol)) return false;
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 3000);
    try {
      const response = await fetch(window.location.pathname, { cache: 'no-store', signal: controller.signal });
      if (!response.ok) return false;
      const fresh = await response.text();
      const match = fresh.match(/const PANEL_VERSION\s*=\s*['"]([^'"]+)['"]/);
      if (match && match[1] && match[1] !== PANEL_VERSION) {
        window.location.replace(`${window.location.pathname}?fresh=${Date.now()}${window.location.hash}`);
        return true;
      }
    } catch {
      return false;
    } finally {
      window.clearTimeout(timer);
    }
    return false;
  }

  function applyTheme(theme) {
    if (theme === 'light') document.documentElement.setAttribute('data-lm', '1');
    if (theme === 'dark') document.documentElement.removeAttribute('data-lm');
  }

  function applyLanguage(value) {
    const requested = String(value || '').toLowerCase();
    language = requested.startsWith('en') ? 'en' : 'ru';
    document.documentElement.lang = language;
    document.title = t('pageTitle');
    document.querySelectorAll('[data-i18n]').forEach(node => {
      node.textContent = t(node.dataset.i18n);
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(node => {
      node.placeholder = t(node.dataset.i18nPlaceholder);
    });
    syncRunButton();
    renderState(currentState, { announce: false, preserveInputs: true });
  }

  function handleHostMessage(data) {
    applyTheme(data.theme);
    if (data.type === 'etb_init') {
      applyLanguage(data.language || data.lang || data.locale || 'ru');
    }
  }

  function showView(name) {
    STATE_VIEWS.forEach(view => {
      el(`state-${view}`).hidden = view !== name;
    });
  }

  function announce(message) { el('live-status').textContent = message; }

  function setRunBusy(busy) {
    runBusy = busy;
    syncRunButton();
  }

  function syncRunButton() {
    const button = el('run-audit');
    const waiting = runBusy || currentState.state === 'running';
    button.disabled = waiting;
    button.textContent = waiting ? t('runningAction') : t('runAction');
  }

  function publicUrl(value) {
    let parsed;
    try { parsed = new URL(value); } catch { return null; }
    const host = parsed.hostname.toLowerCase();
    const privateV4 = /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host);
    const privateV6 = host === '::1' || host === '[::1]' || /^\[?f[cd]/.test(host) || /^\[?fe8/.test(host);
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password
        || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')
        || privateV4 || privateV6) return null;
    return parsed.toString();
  }

  function validTimezone(value) {
    try { new Intl.DateTimeFormat('en', { timeZone: value }).format(); return true; }
    catch { return false; }
  }

  function readSettings() {
    const error = el('settings-error');
    error.hidden = true;
    const siteUrl = publicUrl(el('site-url').value.trim());
    if (!siteUrl) {
      error.textContent = t('invalidUrl'); error.hidden = false; el('site-url').focus(); return null;
    }
    const dailyRunTime = el('daily-time').value;
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(dailyRunTime)) {
      error.textContent = t('invalidTime'); error.hidden = false; el('daily-time').focus(); return null;
    }
    const timezone = el('timezone').value.trim();
    if (!timezone || !validTimezone(timezone)) {
      error.textContent = t('invalidTimezone'); error.hidden = false; el('timezone').focus(); return null;
    }
    return { site_url: siteUrl, daily_run_time: dailyRunTime, timezone };
  }

  function friendlyError(raw, settings = false) {
    if (settings) return t('settingsError');
    const value = String(raw || '').toLowerCase();
    if (/timeout|time|время|timed out/.test(value)) return t('timeoutError');
    if (/url|address|адрес|public|private|loopback/.test(value)) return t('invalidUrlError');
    if (/unavailable|network|fetch|connection|недоступ|подключ/.test(value)) return t('unavailableError');
    return t('genericError');
  }

  function normalizeStatePayload(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      throw new Error('Unexpected expert result');
    }
    const states = new Set(['empty', 'running', 'ready', 'partial', 'failed', 'duplicate', '']);
    if (states.has(payload.state)) {
      if (payload.report && typeof payload.report === 'object' && !Array.isArray(payload.report)) {
        return { ...currentState, ...payload, state: payload.state || 'empty', last_report: payload.report };
      }
      if (payload.run && Array.isArray(payload.tasks) && !payload.last_report) {
        return { ...currentState, state: payload.state || 'empty', last_report: payload };
      }
      return { ...currentState, ...payload, state: payload.state || 'empty' };
    }
    if (payload.run && Array.isArray(payload.tasks)) {
      return { ...currentState, state: 'ready', last_report: payload };
    }
    if (payload.config || payload.schedules) return { ...currentState, ...payload };
    throw new Error('Unexpected expert result');
  }

  function runControlState(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return null;
    return payload.state === 'duplicate' || payload.state === 'running' ? payload.state : null;
  }

  function fillConfig(config = {}) {
    if (typeof config.site_url === 'string') el('site-url').value = config.site_url;
    if (typeof config.daily_run_time === 'string') el('daily-time').value = config.daily_run_time;
    if (typeof config.timezone === 'string') el('timezone').value = config.timezone;
  }

  function formatDate(value) {
    if (!value) return t('notScheduled');
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return t('notScheduled');
    return new Intl.DateTimeFormat(language === 'en' ? 'en' : 'ru', {
      dateStyle: 'medium', timeStyle: 'short',
    }).format(date);
  }

  function nextRunFrom(state) {
    state = state && typeof state === 'object' && !Array.isArray(state) ? state : {};
    const schedules = state.schedules;
    if (Array.isArray(schedules)) {
      const schedule = schedules.find(item => item && Object.prototype.hasOwnProperty.call(item, 'next_run'));
      if (schedule) return schedule.next_run;
      const legacySchedule = schedules.find(item => item && Object.prototype.hasOwnProperty.call(item, 'next_run_at'));
      if (legacySchedule) return legacySchedule.next_run_at;
    }
    if (schedules && typeof schedules === 'object') {
      if (Object.prototype.hasOwnProperty.call(schedules, 'next_run')) return schedules.next_run;
      if (Object.prototype.hasOwnProperty.call(schedules, 'next_run_at')) return schedules.next_run_at;
    }
    if (Object.prototype.hasOwnProperty.call(state, 'next_run')) return state.next_run;
    if (Object.prototype.hasOwnProperty.call(state, 'next_run_at')) return state.next_run_at;
    if (state.config && Object.prototype.hasOwnProperty.call(state.config, 'next_run')) return state.config.next_run;
    return state.config?.next_run_at || null;
  }

  function renderSchedule(state) {
    const config = state.config || {};
    const time = config.daily_run_time || el('daily-time').value || '09:00';
    const timezone = config.timezone || el('timezone').value || 'UTC';
    el('schedule-time').textContent = `${time} ${timezone}`;
    el('next-run').textContent = formatDate(nextRunFrom(state));
  }

  function sourceStatus(status) {
    return ({ ok: 'sourceOk', not_configured: 'sourceNotConfigured', unavailable: 'sourceUnavailable', failed: 'sourceFailed' })[status]
      ? t(({ ok: 'sourceOk', not_configured: 'sourceNotConfigured', unavailable: 'sourceUnavailable', failed: 'sourceFailed' })[status])
      : t('sourceUnknown');
  }

  function severityLabel(severity) {
    const key = ({ critical: 'severityCritical', error: 'severityError', warning: 'severityWarning', info: 'severityInfo' })[severity];
    return key ? t(key) : String(severity || '—');
  }

  function textNode(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    node.textContent = text;
    return node;
  }

  function taskSources(task) {
    const sources = new Set();
    if (Array.isArray(task.sources)) task.sources.forEach(source => sources.add(String(source.name || source)));
    if (task.source) sources.add(String(task.source));
    if (Array.isArray(task.evidence)) task.evidence.forEach(item => {
      if (item && item.source) sources.add(String(item.source));
    });
    return [...sources].filter(Boolean);
  }

  function addTaskField(list, label, value) {
    const row = document.createElement('div');
    row.append(textNode('dt', '', label), textNode('dd', '', value || '—'));
    list.append(row);
  }

  function taskCard(task, index) {
    task = task && typeof task === 'object' ? task : {};
    const card = document.createElement('article');
    card.className = 'task-card';
    const heading = document.createElement('div');
    heading.className = 'task-heading';
    heading.append(
      textNode('h3', '', String(task.rule_key || task.confirmed_fact || task.fact || t('fact'))),
      textNode('span', 'severity', severityLabel(task.severity)),
    );
    card.append(heading, textNode('p', 'task-url', String(task.url || '—')));

    const fields = document.createElement('dl');
    fields.className = 'task-fields';
    addTaskField(fields, t('severity'), severityLabel(task.severity));
    addTaskField(fields, t('url'), String(task.url || '—'));
    addTaskField(fields, t('fact'), String(task.confirmed_fact || task.fact || '—'));
    addTaskField(fields, t('sources'), taskSources(task).join(', ') || '—');
    addTaskField(fields, t('businessImpact'), String(task.business_impact || '—'));
    addTaskField(fields, t('minimalFix'), String(task.minimal_fix || '—'));
    addTaskField(fields, t('verification'), String(task.verification || '—'));
    card.append(fields);

    const details = document.createElement('details');
    details.className = 'evidence';
    const summary = textNode('summary', '', t('evidence'));
    summary.dataset.testid = `evidence-${EVIDENCE_TEST_IDS[index]}`;
    details.append(summary);
    const evidenceList = document.createElement('ul');
    evidenceList.className = 'evidence-list';
    const evidence = Array.isArray(task.evidence) ? task.evidence : [];
    if (!evidence.length) evidenceList.append(textNode('li', '', t('noEvidence')));
    evidence.forEach(item => {
      const entry = document.createElement('li');
      entry.append(
        textNode('strong', '', String(item?.source || t('unnamedSource'))),
        textNode('span', '', [item?.fact, item?.rule].filter(Boolean).map(String).join(' · ') || '—'),
      );
      evidenceList.append(entry);
    });
    details.append(evidenceList);
    card.append(details);
    return card;
  }

  function explicitGroupItems(report, key) {
    const source = report && typeof report === 'object' && !Array.isArray(report) ? report : {};
    const comparison = source.comparison && typeof source.comparison === 'object' && !Array.isArray(source.comparison)
      ? source.comparison : {};
    const values = [comparison[`${key}_items`], comparison[key], source[`${key}_findings`]];
    return values.find(Array.isArray) || null;
  }

  function buildReportModel(report, limit = 10) {
    const source = report && typeof report === 'object' && !Array.isArray(report) ? report : {};
    const comparison = source.comparison && typeof source.comparison === 'object' && !Array.isArray(source.comparison)
      ? source.comparison : {};
    const fullTasks = Array.isArray(source.tasks)
      ? source.tasks.filter(task => task && typeof task === 'object' && !Array.isArray(task)) : [];
    const fullById = new Map(
      fullTasks
        .filter(task => task.task_id !== undefined && task.task_id !== null)
        .map(task => [String(task.task_id), task]),
    );
    const result = { new: [], fixed: [], unchanged: [] };
    const explicit = GROUPS.some(key => explicitGroupItems(report, key));
    if (explicit) {
      GROUPS.forEach(key => {
        result[key] = (explicitGroupItems(source, key) || []).map(item => {
          const stub = item && typeof item === 'object' && !Array.isArray(item) ? item : {};
          const full = stub.task_id === undefined || stub.task_id === null
            ? null : fullById.get(String(stub.task_id));
          return full ? { ...stub, ...full } : { ...stub };
        });
      });
    } else {
      fullTasks.forEach(task => {
        const group = GROUPS.includes(task.comparison_group) ? task.comparison_group : 'new';
        result[group].push({ ...task });
      });
    }

    const counts = {};
    GROUPS.forEach(key => {
      counts[key] = typeof comparison[key] === 'number' ? comparison[key] : result[key].length;
    });
    let remaining = Number.isInteger(limit) && limit >= 0 ? limit : 10;
    GROUPS.forEach(key => {
      result[key] = result[key].slice(0, remaining);
      remaining -= result[key].length;
    });
    return { groups: result, counts };
  }

  function hydrateReportModel(report, limit = 10) {
    return buildReportModel(report, limit);
  }

  function groupedTasks(report) {
    return buildReportModel(report).groups;
  }

  function renderGroup(key, items, comparison, startIndex) {
    const container = el(`${key}-findings`);
    container.replaceChildren();
    const numericCount = typeof comparison?.[key] === 'number' ? comparison[key] : items.length;
    el(`${key}-count`).textContent = String(numericCount);
    if (!items.length) {
      container.append(textNode('p', 'empty-group', numericCount ? t('countOnly') : t('emptyGroup')));
      return startIndex;
    }
    items.forEach((task, offset) => container.append(taskCard(task, startIndex + offset)));
    return startIndex + items.length;
  }

  function renderReport(report, stateName) {
    const sources = (Array.isArray(report.sources) ? report.sources : [])
      .filter(source => source && typeof source === 'object');
    el('run-time').textContent = formatDate(report.run?.completed_at || report.completed_at || currentState.updated_at);
    const sourceList = el('source-list');
    sourceList.replaceChildren();
    if (!sources.length) sourceList.append(textNode('li', '', t('sourceUnknown')));
    sources.forEach(source => sourceList.append(
      textNode('li', '', `${String(source.name || t('unnamedSource'))}: ${sourceStatus(source.status)}`),
    ));

    const partial = stateName === 'partial';
    el('partial-notice').hidden = !partial;
    if (partial) {
      const missing = report.missing_data
        || sources.filter(source => !['ok', 'not_configured'].includes(source.status)).map(source => source.name);
      el('partial-sources').textContent = t('missingSources') + (Array.isArray(missing) && missing.length
        ? missing.map(String).join(', ') : '—');
    }

    const model = buildReportModel(report);
    const groups = model.groups;
    let index = 0;
    GROUPS.forEach(key => { index = renderGroup(key, groups[key], report.comparison || {}, index); });
  }

  function renderState(state, { announce: shouldAnnounce = true, preserveInputs = false } = {}) {
    if (!preserveInputs) fillConfig(state.config || {});
    renderSchedule(state);
    const stateName = state.state || 'empty';
    if (stateName === 'running') {
      showView('running'); el('state-tag').textContent = t('stateRunning');
      if (shouldAnnounce) announce(t('checkingStatus'));
      return;
    }
    if (stateName === 'duplicate') {
      showView('running'); el('state-tag').textContent = t('stateRunning');
      if (shouldAnnounce) announce(t('duplicateStatus'));
      return;
    }
    if (stateName === 'failed') {
      showView('failed'); el('state-tag').textContent = t('stateFailed');
      const message = friendlyError(state.last_error || state.error);
      el('failed-reason').textContent = message;
      if (shouldAnnounce) announce(message);
      return;
    }
    if (stateName === 'ready' || stateName === 'partial') {
      const report = state.last_report || (state.run && state.tasks ? state : null);
      if (!report) {
        showView('failed'); el('state-tag').textContent = t('stateFailed');
        el('failed-reason').textContent = t('genericError');
        if (shouldAnnounce) announce(t('genericError'));
        return;
      }
      showView('result');
      el('state-tag').textContent = t(stateName === 'partial' ? 'statePartial' : 'stateReady');
      renderReport(report, stateName);
      if (shouldAnnounce) announce(t(stateName === 'partial' ? 'partialResultStatus' : 'readyResultStatus'));
      return;
    }
    showView('empty'); el('state-tag').textContent = t('stateEmpty');
    if (shouldAnnounce) announce(t('readyStatus'));
  }

  async function saveConfiguration(event) {
    event.preventDefault();
    const settings = readSettings();
    if (!settings) return;
    const button = el('save-settings');
    button.disabled = true;
    button.textContent = t('savingSettings');
    try {
      const answer = await bridge.run(EXPERT_RUN, { method: 'configure', ...settings, trigger: 'manual' });
      if (!answer.ok) throw new Error(answer.error);
      currentState = normalizeStatePayload(answer.data);
      fillConfig(currentState.config || settings);
      renderSchedule({ ...currentState, config: currentState.config || settings });
      announce(t('savedStatus'));
    } catch (error) {
      const node = el('settings-error');
      node.textContent = friendlyError(error.message, true);
      node.hidden = false;
      announce(node.textContent);
    } finally {
      button.disabled = false;
      button.textContent = t('saveSettings');
    }
  }

  async function runAudit() {
    const settings = readSettings();
    if (!settings) return;
    setRunBusy(true);
    currentState = { ...currentState, state: 'running' };
    renderState(currentState);
    try {
      const answer = await bridge.run(EXPERT_RUN, { method: 'run', ...settings, trigger: 'manual' });
      if (!answer.ok) throw new Error(answer.error);
      const controlState = runControlState(answer.data);
      if (controlState) {
        announce(t(controlState === 'running' ? 'runningStatus' : 'duplicateStatus'));
        await refreshState({ announceLoading: false });
        return;
      }
      currentState = normalizeStatePayload(answer.data);
      renderState(currentState);
    } catch (error) {
      currentState = { ...currentState, state: 'failed', last_error: error.message };
      renderState(currentState);
    } finally {
      setRunBusy(false);
    }
  }

  async function refreshState({ announceLoading = true } = {}) {
    if (!bridge.embedded) {
      renderState(currentState, { announce: false });
      announce(t('standaloneStatus'));
      return currentState;
    }
    setRunBusy(true);
    if (announceLoading) announce(t('loadingState'));
    try {
      const answer = await bridge.run(EXPERT_STATE, { method: 'state' });
      if (!answer.ok) throw new Error(answer.error);
      currentState = normalizeStatePayload(answer.data);
      renderState(currentState);
    } catch (error) {
      currentState = { ...currentState, state: 'failed', last_error: error.message };
      renderState(currentState);
    } finally {
      setRunBusy(false);
    }
    return currentState;
  }

  async function loadState() {
    return refreshState();
  }

  async function boot() {
    if (await healStaleCache()) return;
    const localTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (localTimezone) el('timezone').value = localTimezone;
    bridge = new ExtellaBridge({ allowedExperts: [EXPERT_RUN, EXPERT_STATE], timeoutMs: 240000 });
    bridge.subscribeHost(handleHostMessage);
    el('settings-form').addEventListener('submit', saveConfiguration);
    el('run-audit').addEventListener('click', runAudit);
    applyLanguage('ru');
    await loadState();
    window.__SEO_PANEL_TEST__ = {
      PANEL_VERSION, runAudit, refreshState, renderState, normalizeStatePayload, buildReportModel, hydrateReportModel,
    };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      buildReportModel,
      groupedTasks,
      hydrateReportModel,
      nextRunFrom,
      normalizeStatePayload,
      refreshState,
      runControlState,
    };
  }
  if (typeof document !== 'undefined' && typeof window !== 'undefined') void boot();
})();
