# description: Synchronous public dispatcher for Extella SEO Employee.

from __future__ import annotations

import ipaddress
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import TypedDict


AGENT_ZERO_BASE_URL = os.environ.get("EXTELLA_AGENT_ZERO_BASE_URL", "http://127.0.0.1:50081")
AGENT_ZERO_MESSAGE_PATH = "/api/api_message"
AGENT_ZERO_API_KEY_FILE = Path(
    os.environ.get(
        "EXTELLA_AGENT_ZERO_API_KEY_FILE",
        str(Path.home() / ".extella-seo-employee" / "agent_zero_api_key"),
    )
)
AGENT_ZERO_TIMEOUT_SECONDS = 60.0
NO_TOOLS_PROFILE_ID = "seo_employee_no_tools"
AGENT_ZERO_NO_TOOLS_PROFILE = os.environ.get("EXTELLA_AGENT_ZERO_NO_TOOLS_PROFILE", "").strip()
AGENT_ZERO_NO_TOOLS_ASSERTION_FILE = Path(
    os.environ.get(
        "EXTELLA_AGENT_ZERO_NO_TOOLS_ASSERTION_FILE",
        "/run/bindings/agent_zero_no_tools_profile.json",
    )
)
NO_TOOLS_PROFILE_SCHEMA = "extella.agent_zero_no_tools_profile.v1"


class AgentZeroReply(TypedDict):
    context_id: str
    response: str


class AgentZeroTransportError(RuntimeError):
    pass


def _load_no_tools_profile(
    profile: str = AGENT_ZERO_NO_TOOLS_PROFILE,
    assertion_file: Path = AGENT_ZERO_NO_TOOLS_ASSERTION_FILE,
) -> str:
    if profile != NO_TOOLS_PROFILE_ID:
        raise AgentZeroTransportError("Agent Zero no-tools profile is not configured")
    try:
        value = json.loads(assertion_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise AgentZeroTransportError("Agent Zero no-tools profile assertion is unavailable") from error
    expected = {
        "schema": NO_TOOLS_PROFILE_SCHEMA,
        "agent_profile": profile,
        "tool_policy": {
            "mode": "custom",
            "default": "block",
            "mcp_default": "block",
            "allowed": [],
            "blocked": [],
        },
        "skill_policy": {
            "mode": "custom",
            "default": "block",
            "allowed": [],
            "blocked": [],
        },
    }
    if value != expected:
        raise AgentZeroTransportError("Agent Zero no-tools profile assertion is invalid")
    return profile


def _validate_local_base_url(base_url: str) -> str:
    parsed = urllib.parse.urlsplit(base_url)
    host = parsed.hostname or ""
    try:
        is_loopback = host.lower() in {"localhost", "agent-zero", "agent-zero-proxy", "host.docker.internal"} \
            or ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = False

    if (
        parsed.scheme != "http"
        or not is_loopback
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise AgentZeroTransportError("Agent Zero URL must be a plain loopback HTTP origin")
    try:
        if parsed.port is None:
            raise AgentZeroTransportError("Agent Zero URL must include an explicit port")
    except ValueError as error:
        raise AgentZeroTransportError("Agent Zero URL contains an invalid port") from error
    return base_url.rstrip("/")


def _read_agent_zero_api_key(path: Path) -> str:
    try:
        raw = path.read_text(encoding="utf-8").strip()
        if path.suffix.lower() == ".json":
            value = json.loads(raw)
            raw = value.get("mcp_server_token", "") if isinstance(value, dict) else ""
    except (OSError, json.JSONDecodeError) as error:
        raise AgentZeroTransportError("Agent Zero API key file is unavailable") from error
    if not isinstance(raw, str) or not raw.strip():
        raise AgentZeroTransportError("Agent Zero API key file is empty")
    return raw.strip()


def _call_agent_zero(
    message: str,
    *,
    base_url: str = AGENT_ZERO_BASE_URL,
    api_key_file: Path = AGENT_ZERO_API_KEY_FILE,
    timeout_seconds: float = AGENT_ZERO_TIMEOUT_SECONDS,
    no_tools_profile: str = AGENT_ZERO_NO_TOOLS_PROFILE,
    no_tools_assertion_file: Path = AGENT_ZERO_NO_TOOLS_ASSERTION_FILE,
) -> AgentZeroReply:
    message = str(message).strip()
    if not message:
        raise AgentZeroTransportError("Message is required")
    if timeout_seconds <= 0:
        raise AgentZeroTransportError("Timeout must be positive")

    profile = _load_no_tools_profile(no_tools_profile, no_tools_assertion_file)
    api_key = _read_agent_zero_api_key(api_key_file)

    request = urllib.request.Request(
        _validate_local_base_url(base_url) + AGENT_ZERO_MESSAGE_PATH,
        data=json.dumps(
            {
                "message": message,
                "lifetime_hours": 1,
                "agent_profile": profile,
            }
        ).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "X-API-KEY": api_key,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise AgentZeroTransportError(f"Agent Zero returned HTTP {error.code}") from None
    except (urllib.error.URLError, TimeoutError):
        raise AgentZeroTransportError("Agent Zero is unavailable") from None
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise AgentZeroTransportError("Agent Zero returned invalid JSON") from None

    context_id = payload.get("context_id") if isinstance(payload, dict) else None
    answer = payload.get("response") if isinstance(payload, dict) else None
    if not isinstance(context_id, str) or not context_id or not isinstance(answer, str) or not answer:
        raise AgentZeroTransportError("Agent Zero response does not match the documented API shape")
    return {"context_id": context_id, "response": answer}


_PREFLIGHT_PROMPT = (
    "Do not use tools. Return only this JSON object with exactly two string fields: "
    '{"business_impact":"Проверка маршрута завершена.",'
    '"minimal_fix":"Дополнительных действий не требуется."}'
)


def _error(code: str, message_ru: str, message_en: str) -> str:
    return json.dumps(
        {
            "status": "error",
            "error": {"code": code, "message_ru": message_ru, "message_en": message_en},
        },
        ensure_ascii=False,
    )


def seo_employee_run(
    method: str = "run",
    site_url: str = "",
    daily_run_time: str = "",
    timezone: str = "",
    trigger: str = "manual",
) -> str:
    """Extella entrypoint. It never accepts or forwards a free-form model prompt."""
    if method not in {"run", "configure", "preflight"}:
        return _error(
            "SEO_METHOD_UNSUPPORTED",
            "Поддерживаются только run, configure и preflight.",
            "Only run, configure, and preflight are supported.",
        )

    from seo_employee_service import (
        SeoEmployeeError,
        STATE_PATH,
        _parse_enrichment_response,
        _utc_now,
        atomic_write_json,
        make_state,
        run_seo_employee,
        save_configuration,
    )

    if method == "preflight":
        try:
            reply = _call_agent_zero(_PREFLIGHT_PROMPT)
            _parse_enrichment_response(reply.get("response", ""))
        except (AgentZeroTransportError, SeoEmployeeError):
            return _error(
                "SEO_PREFLIGHT_FAILED",
                "Маршрут модели не прошёл безопасную проверку.",
                "The model route did not pass the safe preflight.",
            )
        return json.dumps({"status": "success", "method": "preflight", "result": "ok"}, ensure_ascii=False)

    if method == "configure":
        try:
            config = save_configuration(site_url, daily_run_time, timezone)
            state = make_state("empty", checked_at=_utc_now(), config=config)
            atomic_write_json(
                STATE_PATH,
                state,
            )
        except (SeoEmployeeError, OSError):
            return _error(
                "SEO_CONFIGURATION_INVALID",
                "Проверьте URL, время запуска и часовой пояс.",
                "Check the URL, run time, and timezone.",
            )
        return json.dumps(
            {"status": "success", "method": "configure", **state},
            ensure_ascii=False,
        )

    try:
        result = run_seo_employee(site_url=site_url, trigger=trigger)
    except SeoEmployeeError:
        return _error(
            "SEO_RUN_INPUT_INVALID",
            "Сначала настройте сайт и проверьте параметры запуска.",
            "Configure the site first and check the run parameters.",
        )
    return json.dumps(result, ensure_ascii=False)
