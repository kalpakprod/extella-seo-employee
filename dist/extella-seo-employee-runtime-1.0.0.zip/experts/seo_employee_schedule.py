# description: One-shot daily scheduler entry for Extella SEO Employee.

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


CONFIG_PATH = Path("/opt/extella-seo-employee/config/config.json")


def seo_employee_schedule(
    *,
    config_path: Path = CONFIG_PATH,
    now_provider: Callable[[], datetime] | None = None,
    run: Callable[..., str] | None = None,
) -> str:
    """Run once when due. Daily de-duplication remains the service's responsibility."""
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict):
            raise ValueError
        if config.get("enabled") is False:
            return json.dumps({"status": "success", "state": "not_due"}, ensure_ascii=False)
        timezone_name = str(config["timezone"])
        scheduled = str(config["daily_run_time"])
        zone = ZoneInfo(timezone_name)
        hour, minute = (int(part) for part in scheduled.split(":"))
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError, ZoneInfoNotFoundError):
        return json.dumps(
            {
                "status": "error",
                "error": {
                    "code": "SEO_SCHEDULE_INVALID",
                    "message_ru": "Суточное расписание не настроено.",
                    "message_en": "The daily schedule is not configured.",
                },
            },
            ensure_ascii=False,
        )
    now = (now_provider or (lambda: datetime.now(timezone.utc)))()
    if now.tzinfo is None:
        return json.dumps(
            {
                "status": "error",
                "error": {
                    "code": "SEO_CLOCK_INVALID",
                    "message_ru": "Системные часы не содержат часовой пояс.",
                    "message_en": "The system clock has no timezone.",
                },
            },
            ensure_ascii=False,
        )
    local = now.astimezone(zone)
    if (local.hour, local.minute) < (hour, minute):
        return json.dumps({"status": "success", "state": "not_due"}, ensure_ascii=False)
    if run is None:
        from seo_employee_run import seo_employee_run

        run = seo_employee_run
    return run(method="run", trigger="daily")


def main() -> int:
    result = seo_employee_schedule()
    print(result)
    try:
        return 1 if json.loads(result).get("status") == "error" else 0
    except (AttributeError, json.JSONDecodeError):
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
