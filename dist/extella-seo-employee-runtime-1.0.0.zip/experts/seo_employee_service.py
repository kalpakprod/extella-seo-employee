# description: Deterministic synchronous service for Extella SEO Employee.

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import socket
import subprocess
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import uuid
from collections.abc import Callable, Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


ROOT_PATH = Path("/opt/extella-seo-employee")
CONFIG_PATH = ROOT_PATH / "config" / "config.json"
STATE_PATH = ROOT_PATH / "state" / "current_state.json"
REPORT_PATH = ROOT_PATH / "reports" / "latest.json"
HISTORY_DIR = ROOT_PATH / "history"
EVIDENCE_DIR = ROOT_PATH / "evidence"
BASELINE_PATH = ROOT_PATH / "state" / "baseline.json"
DAILY_INDEX_PATH = ROOT_PATH / "state" / "daily_runs.json"
LOCK_DIR = ROOT_PATH / "state" / "locks"
DEVICE_BINDING_PATH = Path(
    os.environ.get("EXTELLA_DEVICE_BINDING_FILE", "/run/bindings/device_binding.json")
)
AGENT_BINDING_PATH = Path(
    os.environ.get("EXTELLA_AGENT_BINDING_FILE", "/run/bindings/agent_binding.json")
)
OVERALL_RUN_TIMEOUT_SECONDS = 180.0
SOURCE_TIMEOUT_SECONDS = 120.0
AGENT_ZERO_TIMEOUT_SECONDS = 60.0
SERVICE_INSTANCE_ID = uuid.uuid4().hex
CRAWLSEO_EXECUTABLE = Path(
    os.environ.get("EXTELLA_CRAWLSEO_EXECUTABLE", "/opt/extella-seo-employee/runtime/run_crawlseo")
)
SEOMATOR_EXECUTABLE = Path(
    os.environ.get("EXTELLA_SEOMATOR_EXECUTABLE", "/opt/extella-seo-employee/runtime/run_seomator")
)
DNS_RESOLVER_URL = os.environ.get("EXTELLA_DNS_RESOLVER_URL", "")

REPORT_SCHEMA = "extella.seo_employee_report.v1"
STATE_SCHEMA = "extella.seo_employee_state.v1"
CONFIG_SCHEMA = "extella.seo_employee_config.v1"
NORMALIZER_VERSION = "1.0.1"
ACTIVE_VERSION = "1.0.0"
MODEL_FIELDS = frozenset(
    {
        "rule_key",
        "severity",
        "evidence_level",
        "sources",
        "affected_pages_count",
        "confirmed_fact",
        "url",
    }
)

# Only this rule has been proved end-to-end. New mappings require a registry/version change.
RULE_REGISTRY: dict[str, dict[str, object]] = {
    "meta-description-missing": {
        "severity": "warning",
        "confirmed_fact": "На странице отсутствует meta description.",
        "verification": "Повторить проверку и убедиться, что правило больше не срабатывает.",
        "source_rules": {
            "CrawlSEO": "MISSING_DESCRIPTION",
            "SEOmator": "core-description-present",
        },
    }
}
SOURCE_RULE_REGISTRY = {
    (source, rule): canonical
    for canonical, definition in RULE_REGISTRY.items()
    for source, rule in dict(definition["source_rules"]).items()
}
SOURCE_EVIDENCE_FACTS = {
    ("CrawlSEO", "MISSING_DESCRIPTION"): "Missing meta description",
    ("SEOmator", "core-description-present"): "Meta description is absent",
}

_SECRET_KEY = re.compile(r"(?i)(secret|token|cookie|authorization|api[_-]?key|password|oauth)")
_SECRET_VALUE = re.compile(r"(?i)(bearer\s+\S+|sk-[a-z0-9_-]{8,}|api[_-]?key\s*[:=])")
_UNSUPPORTED_CLAIM = re.compile(
    r"(?i)(%|\b(?:traffic|revenue|profit|client|customer|conversion|ctr|ranking|lead|"
    r"percent|percentage|quantity|metric|increase|decrease|because|caus(?:e|al|ality)|"
    r"many|more|less|significant(?:ly)?|double|multiple|majority|leads?|results?)\b|"
    r"трафик|выручк|доход|прибыл|клиент|покупател|конверси|позици|лид|процент|"
    r"количеств|метрик|увеличит|увеличен|снизит|снижен|привед[её]т|причин|потер[яи]|"
    r"много|большинств|значительн|существенн|кратн|вызыва|обуслов|вед[её]т\s+к)"
)
_TIME_RE = re.compile(r"^(?:[01]\d|2[0-3]):[0-5]\d$")
_DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{2,127}$")
_AGENT_ID_RE = re.compile(r"^agent_[A-Za-z0-9_][A-Za-z0-9_-]{2,127}$")
_SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2}
_EVIDENCE_ORDER = {"verified": 0, "supported": 1, "unverified": 2}
# ponytail: process-local lock assumes one Compose replica; use a shared lease for multi-replica deployment.
_LOCK_ACQUISITION_MUTEX = threading.Lock()


class SeoEmployeeError(RuntimeError):
    pass


class ModelInputError(SeoEmployeeError):
    pass


class RunDeadline:
    """One bounded deadline shared by source collection and model enrichment."""

    def __init__(self, timeout_seconds: float = OVERALL_RUN_TIMEOUT_SECONDS) -> None:
        if timeout_seconds <= 0:
            raise SeoEmployeeError("run deadline must be positive")
        self._expires_at = time.monotonic() + timeout_seconds

    def remaining(self, cap_seconds: float) -> float:
        remaining = min(cap_seconds, self._expires_at - time.monotonic())
        if remaining <= 0:
            raise SeoEmployeeError("SEO run deadline exceeded")
        return remaining


def _worker_resolver(
    host: str,
    _port: object,
    *,
    type: int = 0,
    endpoint: str = DNS_RESOLVER_URL,
) -> list[tuple[object, object, object, object, tuple[str, int]]]:
    parsed = urllib.parse.urlsplit(endpoint)
    if (
        parsed.scheme != "http"
        or parsed.hostname != "dns-resolver"
        or parsed.port != 8083
        or parsed.path != "/resolve"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise OSError("DNS resolver endpoint is invalid")
    request = urllib.request.Request(
        endpoint,
        data=json.dumps({"hostname": host}, separators=(",", ":")).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        raw = response.read(4097)
    if len(raw) > 4096:
        raise OSError("DNS resolver response is too large")
    value = json.loads(raw)
    addresses = value.get("addresses") if isinstance(value, dict) else None
    if not isinstance(addresses, list) or not addresses:
        raise OSError("DNS resolver returned no addresses")
    return [(None, None, type, None, (str(address), 0)) for address in addresses]


PUBLIC_RESOLVER = _worker_resolver if DNS_RESOLVER_URL else socket.getaddrinfo


def _now_utc(now_provider: Callable[[], datetime] | None = None) -> datetime:
    value = (now_provider or (lambda: datetime.now(timezone.utc)))()
    if value.tzinfo is None:
        raise SeoEmployeeError("clock must return a timezone-aware datetime")
    return value.astimezone(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _utc_now() -> str:
    return _iso(_now_utc())


def new_run_id() -> str:
    return f"seo-{uuid.uuid4().hex}"


def _parse_timestamp(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SeoEmployeeError("requested_at must be an ISO 8601 string")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise SeoEmployeeError("requested_at must be an ISO 8601 string") from error
    if parsed.tzinfo is None:
        raise SeoEmployeeError("requested_at must include a timezone")
    return value.strip()


def _resolved_addresses(
    host: str,
    resolver: Callable[..., Iterable[tuple[Any, ...]]],
) -> set[str]:
    try:
        return {str(ipaddress.ip_address(host))}
    except ValueError:
        pass
    try:
        return {str(ipaddress.ip_address(item[4][0])) for item in resolver(host, None, type=socket.SOCK_STREAM)}
    except (OSError, ValueError) as error:
        raise SeoEmployeeError("site_url hostname cannot be resolved") from error


def validate_public_url(
    value: object,
    *,
    resolver: Callable[..., Iterable[tuple[Any, ...]]] = PUBLIC_RESOLVER,
) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SeoEmployeeError("site_url is required")
    raw = value.strip()
    try:
        parsed = urllib.parse.urlsplit(raw)
        port = parsed.port
    except ValueError as error:
        raise SeoEmployeeError("site_url is invalid") from error
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise SeoEmployeeError("site_url must use http or https")
    if parsed.username is not None or parsed.password is not None:
        raise SeoEmployeeError("site_url must not contain userinfo")
    if port is not None and not 1 <= port <= 65535:
        raise SeoEmployeeError("site_url port is invalid")
    addresses = _resolved_addresses(parsed.hostname, resolver)
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise SeoEmployeeError("site_url must resolve only to public addresses")
    return raw


def validate_run_command(
    command: Mapping[str, object],
    *,
    resolver: Callable[..., Iterable[tuple[Any, ...]]] = PUBLIC_RESOLVER,
) -> dict[str, str]:
    required = {"site_id", "site_url", "trigger", "requested_at"}
    if set(command) != required:
        raise SeoEmployeeError("run command must contain exactly site_id, site_url, trigger, requested_at")
    site_id = command["site_id"]
    trigger = command["trigger"]
    if not isinstance(site_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,63}", site_id):
        raise SeoEmployeeError("site_id is invalid")
    if trigger not in {"manual", "daily"}:
        raise SeoEmployeeError("trigger must be manual or daily")
    return {
        "site_id": site_id,
        "site_url": validate_public_url(command["site_url"], resolver=resolver),
        "trigger": str(trigger),
        "requested_at": _parse_timestamp(command["requested_at"]),
    }


def _validate_schedule(daily_run_time: object, timezone_name: object) -> tuple[str, str]:
    if not isinstance(daily_run_time, str) or not _TIME_RE.fullmatch(daily_run_time):
        raise SeoEmployeeError("daily_run_time must use HH:MM")
    if not isinstance(timezone_name, str) or not timezone_name.strip():
        raise SeoEmployeeError("timezone is required")
    try:
        ZoneInfo(timezone_name)
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise SeoEmployeeError("timezone must be an IANA timezone") from error
    return daily_run_time, timezone_name


def site_id_from_url(site_url: str) -> str:
    parsed = urllib.parse.urlsplit(site_url)
    basis = (parsed.hostname or "site").lower()
    if parsed.port is not None:
        basis += f"-{parsed.port}"
    slug = re.sub(r"[^a-z0-9._-]+", "-", basis).strip("-.") or "site"
    if len(slug) > 56:
        slug = slug[:47].rstrip("-.") + "-" + hashlib.sha256(basis.encode()).hexdigest()[:8]
    return slug


def save_configuration(
    site_url: str,
    daily_run_time: str,
    timezone_name: str,
    *,
    config_path: Path = CONFIG_PATH,
    resolver: Callable[..., Iterable[tuple[Any, ...]]] = PUBLIC_RESOLVER,
) -> dict[str, object]:
    validated_url = sanitize_url_for_model(validate_public_url(site_url, resolver=resolver))
    validated_time, validated_zone = _validate_schedule(daily_run_time, timezone_name)
    value: dict[str, object] = {
        "schema": CONFIG_SCHEMA,
        "site_id": site_id_from_url(validated_url),
        "site_url": validated_url,
        "daily_run_time": validated_time,
        "timezone": validated_zone,
    }
    atomic_write_json(config_path, value)
    return value


def load_configuration(config_path: Path = CONFIG_PATH) -> dict[str, object]:
    try:
        value = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise SeoEmployeeError("SEO Employee is not configured") from error
    if not isinstance(value, dict) or value.get("schema") != CONFIG_SCHEMA:
        raise SeoEmployeeError("SEO Employee configuration is invalid")
    if set(value) != {"schema", "site_id", "site_url", "daily_run_time", "timezone"}:
        raise SeoEmployeeError("SEO Employee configuration is invalid")
    return value


def sanitize_url_for_model(value: str) -> str:
    try:
        parsed = urllib.parse.urlsplit(value)
        port = parsed.port
    except ValueError as error:
        raise ModelInputError("model input URL is invalid") from error
    host = parsed.hostname or ""
    if not host or parsed.scheme not in {"http", "https"}:
        raise ModelInputError("model input URL is invalid")
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    netloc = host if port is None else f"{host}:{port}"
    return urllib.parse.urlunsplit((parsed.scheme, netloc, parsed.path or "/", "", ""))


def _source_status(
    name: str,
    status: str,
    obtained_at: str,
    *,
    reason: str | None = None,
) -> dict[str, object]:
    value: dict[str, object] = {"name": name, "status": status, "obtained_at": obtained_at}
    if reason:
        value["reason"] = reason
    return value


def _read_json_object(path: Path) -> dict[str, object] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _run_source_wrapper(
    name: str,
    executable: Path,
    site_url: str,
    output_path: Path,
    *,
    runner: Callable[..., object],
    obtained_at: str,
    timeout_seconds: float,
) -> tuple[dict[str, object], dict[str, object] | None]:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        completed = runner(
            [str(executable), site_url, str(output_path)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        return _source_status(name, "unavailable", obtained_at, reason="wrapper_timeout"), None
    except (OSError, subprocess.SubprocessError):
        return _source_status(name, "unavailable", obtained_at, reason="wrapper_unavailable"), None
    if getattr(completed, "returncode", 1) != 0:
        return _source_status(name, "failed", obtained_at, reason="wrapper_failed"), None
    payload = _read_json_object(output_path)
    if payload is None or not _source_payload_is_valid(name, payload):
        return _source_status(name, "failed", obtained_at, reason="invalid_source_output"), None
    return _source_status(name, "ok", obtained_at), payload


def _source_payload_is_valid(name: str, payload: Mapping[str, object]) -> bool:
    if name == "CrawlSEO":
        crawl = payload.get("crawl")
        return bool(
            payload.get("schema") == "extella.crawlseo_source.v1"
            and payload.get("tool") == "run_crawl"
            and isinstance(crawl, Mapping)
            and crawl.get("status") == "COMPLETED"
            and isinstance(crawl.get("maxPages"), int)
            and not isinstance(crawl.get("maxPages"), bool)
            and crawl["maxPages"] == 1
            and crawl.get("pagesFound") == 1
            and payload.get("tool_calls") == 1
            and payload.get("requested_max_pages") == 1
            and isinstance(payload.get("issues"), list)
        )
    if name == "SEOmator":
        return bool(
            isinstance(payload.get("crawledPages"), int)
            and not isinstance(payload.get("crawledPages"), bool)
            and payload["crawledPages"] == 1
            and isinstance(payload.get("categoryResults"), list)
        )
    return False


def collect_sources(
    site_url: str,
    run_id: str,
    *,
    evidence_dir: Path = EVIDENCE_DIR,
    runner: Callable[..., object] = subprocess.run,
    crawlseo_executable: Path = CRAWLSEO_EXECUTABLE,
    seomator_executable: Path = SEOMATOR_EXECUTABLE,
    obtained_at: str | None = None,
    deadline: RunDeadline | None = None,
) -> tuple[list[dict[str, object]], dict[str, dict[str, object]]]:
    timestamp = obtained_at or _utc_now()
    run_dir = evidence_dir / run_id
    budget = deadline or RunDeadline()
    sources = (
        ("CrawlSEO", crawlseo_executable, "crawlseo.json"),
        ("SEOmator", seomator_executable, "seomator.json"),
    )
    statuses_by_name: dict[str, dict[str, object]] = {}
    payloads: dict[str, dict[str, object]] = {}
    # The wrappers are independent subprocesses. They receive the same absolute
    # budget and the executor is joined before this function returns, so a request
    # never leaves a worker running after the HTTP response.
    with ThreadPoolExecutor(max_workers=len(sources), thread_name_prefix="seo-source") as executor:
        futures = {
            name: executor.submit(
                _run_source_wrapper,
                name,
                executable,
                site_url,
                run_dir / filename,
                runner=runner,
                obtained_at=timestamp,
                timeout_seconds=budget.remaining(SOURCE_TIMEOUT_SECONDS),
            )
            for name, executable, filename in sources
        }
        for name, _executable, _filename in sources:
            try:
                status, payload = futures[name].result(timeout=budget.remaining(SOURCE_TIMEOUT_SECONDS))
            except (SeoEmployeeError, TimeoutError):
                status, payload = _source_status(name, "unavailable", timestamp, reason="wrapper_timeout"), None
            statuses_by_name[name] = status
            if payload is not None:
                payloads[name] = payload
    statuses = [statuses_by_name[name] for name, _executable, _filename in sources]
    statuses.append(
        _source_status(
            "Google Search Console",
            "not_configured",
            timestamp,
            reason="Источник не подключён; выводы о трафике и позициях не формируются.",
        )
    )
    return statuses, payloads


def _crawlseo_occurrences(site_id: str, payload: Mapping[str, object]) -> list[dict[str, object]]:
    crawl = payload.get("crawl")
    issues = payload.get("issues")
    if (
        payload.get("schema") != "extella.crawlseo_source.v1"
        or payload.get("tool") != "run_crawl"
        or not isinstance(crawl, Mapping)
        or crawl.get("status") != "COMPLETED"
        or not isinstance(crawl.get("maxPages"), int)
        or int(crawl["maxPages"]) <= 0
        or not isinstance(issues, list)
    ):
        return []
    occurrences: list[dict[str, object]] = []
    for issue in issues:
        if not isinstance(issue, Mapping):
            continue
        source_rule = str(issue.get("type", ""))
        canonical = SOURCE_RULE_REGISTRY.get(("CrawlSEO", source_rule))
        if canonical is None:
            continue
        try:
            url = sanitize_url_for_model(str(issue.get("url", "")))
        except ModelInputError:
            continue
        occurrences.append(
            {
                "site_id": site_id,
                "url": url,
                "rule_key": canonical,
                "source": "CrawlSEO",
                "source_rule": source_rule,
                "fact": SOURCE_EVIDENCE_FACTS[("CrawlSEO", source_rule)],
            }
        )
    return occurrences


def _seomator_occurrences(site_id: str, payload: Mapping[str, object]) -> list[dict[str, object]]:
    if not isinstance(payload.get("crawledPages"), int):
        return []
    categories = payload.get("categoryResults")
    if not isinstance(categories, list):
        return []
    occurrences: list[dict[str, object]] = []
    for category in categories:
        results = category.get("results") if isinstance(category, Mapping) else None
        if not isinstance(results, list):
            continue
        for result in results:
            if not isinstance(result, Mapping) or result.get("status") != "fail":
                continue
            source_rule = str(result.get("ruleId", ""))
            canonical = SOURCE_RULE_REGISTRY.get(("SEOmator", source_rule))
            if canonical is None:
                continue
            urls = result.get("urls")
            candidates: Sequence[object] = urls if isinstance(urls, list) and urls else [result.get("url") or payload.get("url")]
            for candidate in candidates:
                try:
                    url = sanitize_url_for_model(str(candidate or ""))
                except ModelInputError:
                    continue
                occurrences.append(
                    {
                        "site_id": site_id,
                        "url": url,
                        "rule_key": canonical,
                        "source": "SEOmator",
                        "source_rule": source_rule,
                        "fact": SOURCE_EVIDENCE_FACTS[("SEOmator", source_rule)],
                    }
                )
    return occurrences


def normalize_findings(
    site_id: str,
    payloads: Mapping[str, Mapping[str, object]],
) -> list[dict[str, object]]:
    occurrences: list[dict[str, object]] = []
    crawlseo = payloads.get("CrawlSEO")
    if isinstance(crawlseo, Mapping):
        occurrences.extend(_crawlseo_occurrences(site_id, crawlseo))
    seomator = payloads.get("SEOmator")
    if isinstance(seomator, Mapping):
        occurrences.extend(_seomator_occurrences(site_id, seomator))

    merged: dict[tuple[str, str, str], dict[str, object]] = {}
    for occurrence in occurrences:
        key = (str(occurrence["site_id"]), str(occurrence["url"]), str(occurrence["rule_key"]))
        definition = RULE_REGISTRY.get(key[2])
        if definition is None:
            continue
        finding = merged.setdefault(
            key,
            {
                "site_id": key[0],
                "url": key[1],
                "rule_key": key[2],
                "severity": definition["severity"],
                "affected_pages_count": 1,
                "confirmed_fact": definition["confirmed_fact"],
                "evidence": [],
                "verification": definition["verification"],
            },
        )
        evidence = {
            "source": occurrence["source"],
            "rule": occurrence["source_rule"],
            "fact": occurrence["fact"],
        }
        if evidence not in finding["evidence"]:
            finding["evidence"].append(evidence)

    findings: list[dict[str, object]] = []
    for finding in merged.values():
        sources = {str(item["source"]) for item in finding["evidence"] if isinstance(item, Mapping)}
        finding["evidence_level"] = "verified" if len(sources) >= 2 else "supported"
        finding["evidence"] = sorted(
            finding["evidence"], key=lambda item: (str(item["source"]), str(item["rule"]), str(item["fact"]))
        )
        if finding["evidence_level"] != "unverified":
            findings.append(finding)
    return findings


def prioritize_findings(findings: Iterable[Mapping[str, object]], limit: int = 10) -> list[dict[str, object]]:
    if limit <= 0:
        raise SeoEmployeeError("task limit must be positive")
    verified = [dict(item) for item in findings if item.get("evidence_level") != "unverified"]
    return sorted(
        verified,
        key=lambda item: (
            _SEVERITY_ORDER.get(str(item.get("severity")), 99),
            _EVIDENCE_ORDER.get(str(item.get("evidence_level")), 99),
            -int(item.get("affected_pages_count", 0)),
            str(item.get("url", "")),
            str(item.get("rule_key", "")),
        ),
    )[:limit]


def normalize_one_verified_finding(
    site_id: str,
    crawlseo: Mapping[str, object],
    seomator: Mapping[str, object],
) -> dict[str, object]:
    findings = normalize_findings(site_id, {"CrawlSEO": crawlseo, "SEOmator": seomator})
    if len(findings) != 1 or len(findings[0]["evidence"]) != 2:
        raise SeoEmployeeError("the versioned rule pair is not confirmed by both sources")
    return findings[0]


def build_model_input(finding: Mapping[str, object]) -> dict[str, object]:
    value = {
        "rule_key": finding["rule_key"],
        "severity": finding["severity"],
        "evidence_level": finding["evidence_level"],
        "sources": sorted({str(item["source"]) for item in finding["evidence"] if isinstance(item, Mapping)}),
        "affected_pages_count": finding["affected_pages_count"],
        "confirmed_fact": finding["confirmed_fact"],
        "url": sanitize_url_for_model(str(finding["url"])),
    }
    validate_model_input(value)
    return value


def validate_model_input(value: Mapping[str, object]) -> None:
    if set(value) != MODEL_FIELDS:
        raise ModelInputError("model input fields do not match SC-SEO-031")
    definition = RULE_REGISTRY.get(str(value.get("rule_key")))
    if definition is None:
        raise ModelInputError("model input rule is not allowlisted")
    if value.get("severity") != definition["severity"]:
        raise ModelInputError("model input severity is invalid")
    if value.get("evidence_level") not in {"verified", "supported"}:
        raise ModelInputError("model input evidence level is invalid")
    sources = value.get("sources")
    if not isinstance(sources, list) or not sources or sources != sorted(set(sources)) or any(
        source not in {"CrawlSEO", "SEOmator"} for source in sources
    ):
        raise ModelInputError("model input sources are invalid")
    page_count = value.get("affected_pages_count")
    if not isinstance(page_count, int) or isinstance(page_count, bool) or page_count <= 0:
        raise ModelInputError("model input page count is invalid")
    if value.get("confirmed_fact") != definition["confirmed_fact"]:
        raise ModelInputError("model input fact is not allowlisted")
    url = value.get("url")
    if not isinstance(url, str) or sanitize_url_for_model(url) != url:
        raise ModelInputError("model input URL is not sanitized")


def _default_agent_call(message: str, *, timeout_seconds: float = AGENT_ZERO_TIMEOUT_SECONDS) -> Mapping[str, str]:
    from seo_employee_run import _call_agent_zero

    return _call_agent_zero(message, timeout_seconds=timeout_seconds)


def _parse_enrichment_response(raw_response: object) -> dict[str, str]:
    raw = str(raw_response or "").strip()
    if raw.startswith("```") and raw.endswith("```"):
        raw = "\n".join(raw.splitlines()[1:-1]).strip()
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as error:
        raise SeoEmployeeError("Agent Zero returned invalid enrichment JSON") from error
    if not isinstance(value, dict):
        raise SeoEmployeeError("Agent Zero enrichment fields are invalid")
    return _validate_enrichment(value)


def enrich_with_agent_zero(
    model_input: Mapping[str, object],
    *,
    agent_call: Callable[[str], Mapping[str, str]] = _default_agent_call,
    timeout_seconds: float = AGENT_ZERO_TIMEOUT_SECONDS,
) -> dict[str, str]:
    validate_model_input(model_input)
    prompt = (
        "Do not use tools. Return only a JSON object with exactly the string keys "
        '"business_impact" and "minimal_fix". Write one short Russian sentence per value. '
        "Use only the supplied fact. Do not invent quantities, traffic, revenue, clients or causality. "
        "Do not use digits. FACT_INPUT="
        + json.dumps(dict(model_input), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    )
    if agent_call is _default_agent_call:
        reply = _default_agent_call(prompt, timeout_seconds=timeout_seconds)
    else:
        reply = agent_call(prompt)
    return _parse_enrichment_response(reply.get("response", ""))


def _validate_enrichment(value: Mapping[str, object]) -> dict[str, str]:
    if set(value) != {"business_impact", "minimal_fix"}:
        raise SeoEmployeeError("Agent Zero enrichment fields are invalid")
    cleaned: dict[str, str] = {}
    for field in ("business_impact", "minimal_fix"):
        text = value.get(field)
        if (
            not isinstance(text, str)
            or not text.strip()
            or len(text) > 600
            or any(ch.isdigit() for ch in text)
            or _UNSUPPORTED_CLAIM.search(text)
        ):
            raise SeoEmployeeError("Agent Zero enrichment contains unsupported claims")
        cleaned[field] = text.strip()
    return cleaned


def _assert_no_secret_material(value: object, path: str = "$") -> None:
    if isinstance(value, Mapping):
        for key, nested in value.items():
            if _SECRET_KEY.search(str(key)):
                raise SeoEmployeeError(f"unsafe field in snapshot at {path}")
            _assert_no_secret_material(nested, f"{path}.{key}")
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            _assert_no_secret_material(nested, f"{path}[{index}]")
    elif isinstance(value, str) and _SECRET_VALUE.search(value):
        raise SeoEmployeeError(f"unsafe value in snapshot at {path}")


def atomic_write_json(path: Path, value: Mapping[str, object]) -> None:
    _assert_no_secret_material(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = ""
    try:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
        ) as handle:
            temporary = handle.name
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def _safe_read_json(path: Path) -> dict[str, object] | None:
    return _read_json_object(path)


def _next_scheduled_run(config: Mapping[str, object] | None, checked_at: str) -> str | None:
    if not isinstance(config, Mapping):
        return None
    scheduled = config.get("daily_run_time")
    timezone_name = config.get("timezone")
    if not isinstance(scheduled, str) or not isinstance(timezone_name, str) or not _TIME_RE.fullmatch(scheduled):
        return None
    try:
        checked = datetime.fromisoformat(checked_at.replace("Z", "+00:00"))
        if checked.tzinfo is None:
            return None
        zone = ZoneInfo(timezone_name)
    except (ValueError, ZoneInfoNotFoundError):
        return None
    hour, minute = (int(part) for part in scheduled.split(":"))
    local = checked.astimezone(zone)
    candidate = datetime(local.year, local.month, local.day, hour, minute, tzinfo=zone)
    if candidate <= local:
        candidate += timedelta(days=1)
    return candidate.isoformat()


def _schedule_state(config: Mapping[str, object] | None, checked_at: str) -> list[dict[str, object]]:
    if not config:
        return []
    return [{"id": "seo_employee_daily_scan", "active": True, "next_run": _next_scheduled_run(config, checked_at)}]


def _empty_binding() -> dict[str, object]:
    return {
        "hosting_profile": None,
        "host": None,
        "platform_profile_id": None,
        "account_ref": None,
        "agent_ids": None,
        "since": None,
        "device_id": None,
    }


def _valid_binding_timestamp(value: object) -> bool:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        return False
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).tzinfo is not None
    except ValueError:
        return False


def _read_state_binding(
    *,
    device_binding_path: Path = DEVICE_BINDING_PATH,
    agent_binding_path: Path = AGENT_BINDING_PATH,
) -> dict[str, object]:
    device_exists = device_binding_path.is_file()
    agent_exists = agent_binding_path.is_file()
    if not device_exists and not agent_exists:
        return _empty_binding()
    device = _safe_read_json(device_binding_path) if device_exists else None
    agent = _safe_read_json(agent_binding_path) if agent_exists else None
    # A partial or malformed binding must never be upgraded into a claimed identity.
    if device_exists and (
        not isinstance(device, Mapping)
        or set(device) != {"device_id", "host", "hosting_profile", "since"}
        or not isinstance(device.get("device_id"), str)
        or not _DEVICE_ID_RE.fullmatch(str(device.get("device_id")))
        or not isinstance(device.get("host"), str)
        or not device["host"].strip()
        or device["host"] != device["host"].strip()
        or device.get("hosting_profile") not in {"local", "server", "client_server"}
        or not _valid_binding_timestamp(device.get("since"))
    ):
        return _empty_binding()
    if agent_exists and (
        not isinstance(agent, Mapping)
        or set(agent) != {"agent_id"}
        or not isinstance(agent.get("agent_id"), str)
        or not _AGENT_ID_RE.fullmatch(str(agent.get("agent_id")))
    ):
        return _empty_binding()
    binding = _empty_binding()
    if isinstance(device, Mapping):
        binding.update(
            {
                "hosting_profile": device["hosting_profile"],
                "host": device["host"],
                "since": device["since"],
                "device_id": device["device_id"],
                "agent_ids": [],
            }
        )
    if isinstance(agent, Mapping):
        binding["agent_ids"] = [agent["agent_id"]]
    return binding


def make_state(
    state: str,
    *,
    checked_at: str,
    config: Mapping[str, object] | None,
    run_id: str | None = None,
    trigger: str | None = None,
    last_report: Mapping[str, object] | None = None,
    last_error: Mapping[str, str] | None = None,
    device_binding_path: Path = DEVICE_BINDING_PATH,
    agent_binding_path: Path = AGENT_BINDING_PATH,
) -> dict[str, object]:
    if state not in {"empty", "running", "ready", "partial", "failed"}:
        raise SeoEmployeeError("state is invalid")
    last_result = {"ready": "ok", "partial": "partial", "failed": "failed"}.get(state)
    return {
        "status": "success",
        "schema": STATE_SCHEMA,
        "state": state,
        "run_id": run_id,
        "updated_at": checked_at,
        "config": dict(config) if config else None,
        "last_report": dict(last_report) if last_report else None,
        "enabled": config is not None,
        "active_version": ACTIVE_VERSION,
        "last_run": {"at": checked_at, "kind": trigger} if run_id else None,
        "last_result": last_result,
        "last_error": dict(last_error) if last_error else None,
        "schedules": _schedule_state(config, checked_at),
        "checked_at": checked_at,
        "bound_to": _read_state_binding(
            device_binding_path=device_binding_path,
            agent_binding_path=agent_binding_path,
        ),
    }


def _safe_failure(code: str) -> dict[str, str]:
    messages = {
        "SEO_SOURCES_UNAVAILABLE": (
            "Источники аудита недоступны. Проверьте локальные обёртки и запустите снова вручную.",
            "Audit sources are unavailable. Check the local wrappers and run again manually.",
        ),
        "SEO_REPORT_SAVE_FAILED": (
            "Отчёт не сохранён. Проверьте локальное хранилище и запустите снова вручную.",
            "The report was not saved. Check local storage and run again manually.",
        ),
        "SEO_RUN_FAILED": (
            "Запуск завершился ошибкой. Проверьте локальную установку и запустите снова вручную.",
            "The run failed. Check the local installation and run again manually.",
        ),
    }
    ru, en = messages[code]
    return {"code": code, "message_ru": ru, "message_en": en}


def _task_identity(task: Mapping[str, object]) -> str:
    return hashlib.sha256(
        f'{task["site_id"]}\0{task["url"]}\0{task["rule_key"]}'.encode("utf-8")
    ).hexdigest()[:16]


def compare_with_baseline(
    tasks: Sequence[Mapping[str, object]], baseline: Mapping[str, object] | None
) -> tuple[dict[str, object], dict[str, object]]:
    current: dict[str, dict[str, object]] = {}
    for task in tasks:
        card = dict(task)
        _assert_no_secret_material(card)
        current[str(card["task_id"])] = card
    # Reports are capped to ten tasks. Preserve the same bounded, deterministic
    # set in the baseline even when this helper is called directly.
    current = {task_id: current[task_id] for task_id in sorted(current)[:10]}
    previous_items = baseline.get("items", []) if isinstance(baseline, Mapping) else []
    previous: dict[str, dict[str, object]] = {}
    if isinstance(previous_items, list):
        for item in previous_items:
            if not isinstance(item, Mapping) or not isinstance(item.get("task_id"), str):
                continue
            card = dict(item)
            try:
                _assert_no_secret_material(card)
            except SeoEmployeeError:
                continue
            previous[str(card["task_id"])] = card
    new_ids = sorted(set(current) - set(previous))
    fixed_ids = sorted(set(previous) - set(current))
    unchanged_ids = sorted(set(current) & set(previous))
    comparison: dict[str, object] = {
        "baseline": "compared" if baseline is not None else "created",
        "new": len(new_ids),
        "fixed": len(fixed_ids),
        "unchanged": len(unchanged_ids),
        "new_items": [current[item] for item in new_ids],
        "fixed_items": [previous[item] for item in fixed_ids],
        "unchanged_items": [current[item] for item in unchanged_ids],
    }
    next_baseline: dict[str, object] = {
        "schema": "extella.seo_employee_baseline.v1",
        "items": [current[item] for item in sorted(current)],
    }
    return comparison, next_baseline


def _daily_key(site_id: str, now: datetime, timezone_name: str) -> str:
    try:
        local_date = now.astimezone(ZoneInfo(timezone_name)).date().isoformat()
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise SeoEmployeeError("timezone must be an IANA timezone") from error
    return f"{site_id}|{local_date}|{timezone_name}"


def _lock_path(lock_dir: Path, site_id: str) -> Path:
    return lock_dir / f"{hashlib.sha256(site_id.encode()).hexdigest()[:16]}.lock"


def _acquire_lock(
    lock_path: Path,
    run_id: str,
    site_id: str,
    *,
    instance_id: str = SERVICE_INSTANCE_ID,
) -> tuple[bool, str]:
    with _LOCK_ACQUISITION_MUTEX:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"run_id": run_id, "site_id": site_id, "instance_id": instance_id}
        try:
            descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            existing = _safe_read_json(lock_path)
            existing_id = existing.get("run_id") if isinstance(existing, Mapping) else None
            owner = existing.get("instance_id") if isinstance(existing, Mapping) else None
            # Compose runs a single product replica. A different process identity can
            # therefore only be residue from a killed/restarted container, not an
            # active peer. Replace it atomically so SIGKILL cannot wedge the product.
            if owner != instance_id:
                atomic_write_json(lock_path, payload)
                return True, run_id
            return False, str(existing_id) if isinstance(existing_id, str) and existing_id else "unknown"
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(json.dumps(payload, separators=(",", ":")).encode())
            handle.flush()
            os.fsync(handle.fileno())
        return True, run_id


def _release_lock(lock_path: Path, run_id: str) -> None:
    existing = _safe_read_json(lock_path)
    if isinstance(existing, Mapping) and existing.get("run_id") == run_id:
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


def _completed_daily_run(daily_index: Mapping[str, object], daily_key: str) -> str | None:
    runs = daily_index.get("runs")
    if not isinstance(runs, Mapping):
        raise SeoEmployeeError("daily run index is invalid")
    prior = runs.get(daily_key)
    if isinstance(prior, str) and prior:
        return prior  # Legacy completed index entry.
    if isinstance(prior, Mapping) and prior.get("completed") is True:
        run_id = prior.get("run_id")
        return run_id if isinstance(run_id, str) and run_id else None
    return None


def _record_completed_daily_run(
    daily_index_path: Path,
    daily_key: str,
    run_id: str,
    state: str,
) -> None:
    index = _safe_read_json(daily_index_path) or {
        "schema": "extella.seo_employee_daily_runs.v1",
        "runs": {},
    }
    if index.get("schema") != "extella.seo_employee_daily_runs.v1" or not isinstance(index.get("runs"), dict):
        raise SeoEmployeeError("daily run index is invalid")
    index["runs"][daily_key] = {"run_id": run_id, "state": state, "completed": True}
    atomic_write_json(daily_index_path, index)


def _save_completed_report(
    report: Mapping[str, object],
    *,
    report_path: Path,
    history_dir: Path,
) -> None:
    run = report.get("run")
    if not isinstance(run, Mapping) or not isinstance(run.get("run_id"), str):
        raise SeoEmployeeError("report run identity is invalid")
    history_path = history_dir / f'{run["run_id"]}.json'
    atomic_write_json(history_path, report)
    atomic_write_json(report_path, report)


def run_seo_employee(
    *,
    site_url: str,
    trigger: str = "manual",
    config_path: Path = CONFIG_PATH,
    state_path: Path = STATE_PATH,
    report_path: Path = REPORT_PATH,
    history_dir: Path = HISTORY_DIR,
    evidence_dir: Path = EVIDENCE_DIR,
    baseline_path: Path = BASELINE_PATH,
    daily_index_path: Path = DAILY_INDEX_PATH,
    lock_dir: Path = LOCK_DIR,
    resolver: Callable[..., Iterable[tuple[Any, ...]]] = PUBLIC_RESOLVER,
    process_runner: Callable[..., object] = subprocess.run,
    enricher: Callable[[Mapping[str, object]], Mapping[str, str]] = enrich_with_agent_zero,
    now_provider: Callable[[], datetime] | None = None,
    crawlseo_executable: Path = CRAWLSEO_EXECUTABLE,
    seomator_executable: Path = SEOMATOR_EXECUTABLE,
) -> dict[str, object]:
    config = load_configuration(config_path)
    effective_url = site_url.strip() or str(config["site_url"])
    now = _now_utc(now_provider)
    command = validate_run_command(
        {
            "site_id": config["site_id"],
            "site_url": effective_url,
            "trigger": trigger,
            "requested_at": _iso(now),
        },
        resolver=resolver,
    )
    if effective_url != config["site_url"]:
        raise SeoEmployeeError("site_url does not match the configured site")

    deadline = RunDeadline()
    run_id = new_run_id()
    lock_path = _lock_path(lock_dir, command["site_id"])
    acquired, active_run_id = _acquire_lock(lock_path, run_id, command["site_id"])
    if not acquired:
        return {"status": "success", "state": "duplicate", "run_id": active_run_id, "duplicate": True}

    daily_key: str | None = None
    try:
        if trigger == "daily":
            _validate_schedule(config["daily_run_time"], config["timezone"])
            daily_key = _daily_key(command["site_id"], now, str(config["timezone"]))
            daily_index = _safe_read_json(daily_index_path) or {"schema": "extella.seo_employee_daily_runs.v1", "runs": {}}
            prior = _completed_daily_run(daily_index, daily_key)
            if prior:
                return {"status": "success", "state": "duplicate", "run_id": prior, "duplicate": True}

        previous_report = _safe_read_json(report_path)
        started_at = _iso(now)
        atomic_write_json(
            state_path,
            make_state(
                "running",
                checked_at=started_at,
                config=config,
                run_id=run_id,
                trigger=trigger,
                last_report=previous_report,
            ),
        )
        statuses, payloads = collect_sources(
            command["site_url"],
            run_id,
            evidence_dir=evidence_dir,
            runner=process_runner,
            crawlseo_executable=crawlseo_executable,
            seomator_executable=seomator_executable,
            obtained_at=started_at,
            deadline=deadline,
        )
        factual_sources = [item for item in statuses if item["name"] != "Google Search Console" and item["status"] == "ok"]
        findings = prioritize_findings(normalize_findings(command["site_id"], payloads))
        tasks: list[dict[str, object]] = []
        missing = [str(item["name"]) for item in statuses if item["name"] != "Google Search Console" and item["status"] != "ok"]
        model_missing = False
        for finding in findings:
            task = {"task_id": _task_identity(finding), **finding}
            try:
                model_input = build_model_input(finding)
                if enricher is enrich_with_agent_zero:
                    task.update(enrich_with_agent_zero(model_input, timeout_seconds=deadline.remaining(AGENT_ZERO_TIMEOUT_SECONDS)))
                else:
                    task.update(_validate_enrichment(enricher(model_input)))
            except (SeoEmployeeError, OSError, RuntimeError):
                model_missing = True
            tasks.append(task)
        if model_missing:
            missing.append("Agent Zero")

        if not factual_sources:
            result_state = "failed"
        elif len(factual_sources) == 2 and not model_missing:
            result_state = "ready"
        else:
            result_state = "partial"
        completed_at = _iso(_now_utc(now_provider))
        baseline = _safe_read_json(baseline_path)
        if not isinstance(baseline, Mapping) or baseline.get("site_id") != command["site_id"]:
            baseline = None
        if result_state == "failed":
            comparison = {
                "baseline": "not_compared",
                "new": 0,
                "fixed": 0,
                "unchanged": 0,
                "new_items": [],
                "fixed_items": [],
                "unchanged_items": [],
            }
            next_baseline: dict[str, object] = {}
        else:
            comparison, next_baseline = compare_with_baseline(tasks, baseline)
            next_baseline["site_id"] = command["site_id"]
            if result_state == "partial":
                comparison["fixed"] = 0
                comparison["fixed_items"] = []
        report: dict[str, object] = {
            "schema": REPORT_SCHEMA,
            "normalizer_version": NORMALIZER_VERSION,
            "run": {**command, "run_id": run_id, "started_at": started_at, "completed_at": completed_at},
            "state": result_state,
            "sources": statuses,
            "missing_data": sorted(set(missing)),
            "comparison": comparison,
            "tasks": tasks,
        }
        if result_state == "failed":
            report["error"] = _safe_failure("SEO_SOURCES_UNAVAILABLE")

        _save_completed_report(
            report,
            report_path=report_path,
            history_dir=history_dir,
        )
        if daily_key is not None:
            _record_completed_daily_run(daily_index_path, daily_key, run_id, result_state)
        last_error = report.get("error") if result_state == "failed" else None
        atomic_write_json(
            state_path,
            make_state(
                result_state,
                checked_at=completed_at,
                config=config,
                run_id=run_id,
                trigger=trigger,
                last_report=report,
                last_error=last_error if isinstance(last_error, Mapping) else None,
            ),
        )
        if result_state == "ready":
            atomic_write_json(baseline_path, next_baseline)
        return {"status": "success" if result_state == "ready" else result_state, "state": result_state, "run_id": run_id, "report": report}
    except Exception:
        failed_at = _iso(_now_utc(now_provider))
        error = _safe_failure("SEO_RUN_FAILED")
        try:
            atomic_write_json(
                state_path,
                make_state(
                    "failed",
                    checked_at=failed_at,
                    config=config,
                    run_id=run_id,
                    trigger=trigger,
                    last_report=_safe_read_json(report_path),
                    last_error=error,
                ),
            )
        except (OSError, SeoEmployeeError):
            pass
        return {"status": "failed", "state": "failed", "run_id": run_id, "error": error}
    finally:
        _release_lock(lock_path, run_id)


def complete_from_evidence(
    command: Mapping[str, object],
    *,
    crawlseo_path: Path,
    seomator_path: Path,
    report_path: Path,
    state_path: Path,
    resolver: Callable[..., Iterable[tuple[Any, ...]]] = PUBLIC_RESOLVER,
    enricher: Callable[[Mapping[str, object]], Mapping[str, str]] = enrich_with_agent_zero,
) -> dict[str, object]:
    validated = validate_run_command(command, resolver=resolver)
    crawlseo = _read_json_object(crawlseo_path)
    seomator = _read_json_object(seomator_path)
    if crawlseo is None or seomator is None:
        raise SeoEmployeeError("source evidence must be JSON objects")
    finding = normalize_one_verified_finding(validated["site_id"], crawlseo, seomator)
    enrichment = _validate_enrichment(enricher(build_model_input(finding)))
    run_id = new_run_id()
    completed_at = _utc_now()
    task = {"task_id": _task_identity(finding), **finding, **enrichment}
    comparison, _baseline = compare_with_baseline([task], None)
    report: dict[str, object] = {
        "schema": REPORT_SCHEMA,
        "normalizer_version": NORMALIZER_VERSION,
        "run": {"run_id": run_id, **validated, "started_at": completed_at, "completed_at": completed_at},
        "state": "ready",
        "sources": [
            _source_status("CrawlSEO", "ok", completed_at),
            _source_status("SEOmator", "ok", completed_at),
            _source_status("Google Search Console", "not_configured", completed_at, reason="Источник не подключён; выводы о трафике и позициях не формируются."),
        ],
        "missing_data": [],
        "comparison": comparison,
        "tasks": [task],
    }
    atomic_write_json(report_path, report)
    config = {
        "schema": CONFIG_SCHEMA,
        "site_id": validated["site_id"],
        "site_url": validated["site_url"],
        "daily_run_time": "00:00",
        "timezone": "UTC",
    }
    atomic_write_json(
        state_path,
        make_state("ready", checked_at=completed_at, config=config, run_id=run_id, trigger=validated["trigger"], last_report=report),
    )
    return report
