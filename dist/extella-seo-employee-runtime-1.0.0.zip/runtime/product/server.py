#!/usr/bin/env python3
"""Loopback-bound HTTP facade and daily scheduler for the Docker deployment."""

from __future__ import annotations

import hmac
import json
import os
import pathlib
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


PRODUCT_ROOT = pathlib.Path("/opt/extella-seo-employee")
sys.path.insert(0, str(PRODUCT_ROOT / "experts"))

from seo_employee_run import seo_employee_run  # noqa: E402
from seo_employee_schedule import CONFIG_PATH, seo_employee_schedule  # noqa: E402
from seo_employee_state import seo_employee_state  # noqa: E402


VERSION = "1.0.0"
MAX_BODY_BYTES = 16_384
TOKEN_FILE = pathlib.Path(os.environ.get("EXTELLA_SEO_API_TOKEN_FILE", "/run/secrets/seo_employee_api_token"))
RUN_DEADLINE_SECONDS = 180.0


def read_token(path: pathlib.Path = TOKEN_FILE) -> str:
    token = path.read_text(encoding="utf-8").strip()
    if len(token) < 32:
        raise RuntimeError("SEO Employee API token is missing or too short")
    return token


def dispatch(method: str, path: str, body: dict[str, object]) -> tuple[int, dict[str, object]]:
    if method == "GET" and path == "/api/state":
        return 200, json.loads(seo_employee_state())
    if method != "POST":
        return 405, {"status": "error", "code": "method_not_allowed"}
    if path == "/api/configure" and set(body) <= {"site_url", "daily_run_time", "timezone"}:
        result = seo_employee_run(
            method="configure",
            site_url=str(body.get("site_url", "")),
            daily_run_time=str(body.get("daily_run_time", "")),
            timezone=str(body.get("timezone", "")),
        )
    elif path == "/api/run" and set(body) <= {"site_url"}:
        result = seo_employee_run(method="run", site_url=str(body.get("site_url", "")), trigger="manual")
    elif path == "/api/preflight" and not body:
        result = seo_employee_run(method="preflight")
    else:
        return 404, {"status": "error", "code": "route_not_found"}
    payload = json.loads(result)
    state = payload.get("state")
    if state == "duplicate":
        return 202, payload
    if state in {"ready", "partial"} or payload.get("status") == "success":
        return 200, payload
    error = payload.get("error")
    code = error.get("code") if isinstance(error, dict) else ""
    if code in {"SEO_RUN_INPUT_INVALID", "SEO_CONFIGURATION_INVALID", "SEO_METHOD_UNSUPPORTED"}:
        return 400, payload
    return 503, payload


def handler(api_token: str) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "ExtellaSEOEmployee/1.0"

        def _send(self, status: int, payload: dict[str, object]) -> None:
            body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _authorized(self) -> bool:
            bearer = self.headers.get("Authorization", "")
            supplied = bearer[7:] if bearer.startswith("Bearer ") else self.headers.get("X-API-KEY", "")
            return bool(supplied) and hmac.compare_digest(supplied, api_token)

        def _body(self) -> dict[str, object]:
            if self.headers.get("Transfer-Encoding"):
                raise ValueError("transfer encoding is not supported")
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError as error:
                raise ValueError("invalid content length") from error
            if length < 0 or length > MAX_BODY_BYTES:
                raise ValueError("request body is too large")
            if not length:
                return {}
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ValueError("request body must be an object")
            return payload

        def do_GET(self) -> None:
            if self.path == "/health":
                self._send(200, {"status": "ok", "version": VERSION})
                return
            if not self._authorized():
                self._send(401, {"status": "error", "code": "unauthorized"})
                return
            try:
                status, payload = dispatch("GET", self.path, {})
            except (OSError, ValueError, json.JSONDecodeError):
                status, payload = 500, {"status": "error", "code": "internal_error"}
            self._send(status, payload)

        def do_POST(self) -> None:
            if not self._authorized():
                self._send(401, {"status": "error", "code": "unauthorized"})
                return
            try:
                status, payload = dispatch("POST", self.path, self._body())
            except (OSError, ValueError, json.JSONDecodeError):
                status, payload = 400, {"status": "error", "code": "invalid_request"}
            self._send(status, payload)

        def log_message(self, _format: str, *_args: object) -> None:
            return

    return Handler


def schedule_loop(stop: threading.Event, wait_seconds: float = 60.0) -> None:
    while not stop.is_set():
        if CONFIG_PATH.is_file():
            try:
                result = json.loads(seo_employee_schedule())
                if result.get("status") == "error":
                    print(json.dumps({"status": "error", "code": "schedule_check_failed"}), file=sys.stderr)
            except (OSError, ValueError, json.JSONDecodeError):
                print(json.dumps({"status": "error", "code": "schedule_check_failed"}), file=sys.stderr)
        stop.wait(wait_seconds)


def main() -> int:
    try:
        api_token = read_token()
        port = int(os.environ.get("PORT", "8080"))
        if not 1 <= port <= 65535:
            raise ValueError
    except (OSError, RuntimeError, ValueError):
        print(json.dumps({"status": "error", "code": "startup_configuration_invalid"}))
        return 1
    stop = threading.Event()
    scheduler = threading.Thread(target=schedule_loop, args=(stop,), daemon=True)
    scheduler.start()
    server = ThreadingHTTPServer(("0.0.0.0", port), handler(api_token))
    try:
        server.serve_forever()
    finally:
        stop.set()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
