import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

if (process.argv[2] === "--serve") {
  await import("./extella_worker_server.mjs");
} else {

const [siteUrl, outputPath] = process.argv.slice(2);
if (!siteUrl || !outputPath) {
  throw new Error("usage: seomator <public-url> <output-path>");
}
const parsedUrl = new URL(siteUrl);
if (!["http:", "https:"].includes(parsedUrl.protocol)) {
  throw new Error("site URL must use http or https");
}

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
const temporary = `${outputPath}.${process.pid}.tmp`;
const result = spawnSync(
  "node",
  [
    "/app/dist/cli.js",
    "audit",
    parsedUrl.toString(),
    "--categories",
    "core",
    "--format",
    "json",
    "--output",
    temporary,
    "--no-cwv",
    "--max-pages",
    "1",
    "--timeout",
    "30000",
  ],
  { cwd: "/work", env: process.env, stdio: "inherit" },
);
if (![0, 1].includes(result.status) || !fs.existsSync(temporary)) {
  fs.rmSync(temporary, { force: true });
  process.exit(result.status ?? 2);
}
const report = JSON.parse(fs.readFileSync(temporary, "utf8"));
if (report.error || report.crawledPages !== 1) {
  fs.rmSync(temporary, { force: true });
  throw new Error("SEOmator did not produce a one-page report");
}
fs.renameSync(temporary, outputPath);
console.log(JSON.stringify({ source: "SEOmator", crawledPages: 1, output: path.basename(outputPath) }));
}
