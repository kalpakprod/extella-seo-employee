#!/usr/bin/env python3
"""Call an internal source worker and atomically store its JSON result."""

from __future__ import annotations

import json
import os
import pathlib
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request


ENDPOINTS = {
    "CrawlSEO": os.environ.get("EXTELLA_CRAWLSEO_URL", "http://crawlseo:8081/run"),
    "SEOmator": os.environ.get("EXTELLA_SEOMATOR_URL", "http://seomator:8082/run"),
}
ALLOWED_HOSTS = {"crawlseo", "seomator", "127.0.0.1", "localhost"}
MAX_RESPONSE_BYTES = 10_000_000


def _endpoint(value: str) -> str:
    parsed = urllib.parse.urlsplit(value)
    if (
        parsed.scheme != "http"
        or parsed.hostname not in ALLOWED_HOSTS
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path != "/run"
        or parsed.port is None
    ):
        raise ValueError("source worker endpoint is not allowed")
    return value


def proxy_source(source: str, site_url: str, output_path: pathlib.Path) -> None:
    endpoint = _endpoint(ENDPOINTS[source])
    request = urllib.request.Request(
        endpoint,
        data=json.dumps({"site_url": site_url}, separators=(",", ":")).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=180) as response:
        raw = response.read(MAX_RESPONSE_BYTES + 1)
    if len(raw) > MAX_RESPONSE_BYTES:
        raise ValueError("source worker response is too large")
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise ValueError("source worker response is not an object")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = ""
    try:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", dir=output_path.parent,
            prefix=f".{output_path.name}.", suffix=".tmp", delete=False,
        ) as handle:
            temporary = handle.name
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, output_path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def main(argv: list[str]) -> int:
    if len(argv) != 3 or argv[0] not in ENDPOINTS:
        print("usage: source_proxy.py <CrawlSEO|SEOmator> <public-url> <output-json>", file=sys.stderr)
        return 2
    try:
        proxy_source(argv[0], argv[1], pathlib.Path(argv[2]))
    except (OSError, ValueError, KeyError, json.JSONDecodeError, urllib.error.URLError):
        print("source worker request failed", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
