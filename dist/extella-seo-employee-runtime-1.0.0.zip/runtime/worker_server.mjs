import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { lookup } from "node:dns/promises";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const kind = process.env.EXTELLA_WORKER_KIND;
const port = Number(process.env.EXTELLA_WORKER_PORT);
if (!['CrawlSEO', 'SEOmator', 'Resolver'].includes(kind) || !Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("worker configuration is invalid");
}

const MAX_BODY_BYTES = 4096;
const MAX_REPORT_BYTES = 10_000_000;
const AUDIT_TIMEOUT_MS = 180_000;
let busy = false;

function isReady() {
  if (kind === "Resolver") return true;
  if (kind === "CrawlSEO") {
    try {
      const databaseUrl = new URL(process.env.DATABASE_URL || "");
      return databaseUrl.protocol === "postgresql:" && databaseUrl.hostname.length > 0;
    } catch {
      return false;
    }
  }
  return process.env.PLAYWRIGHT_BROWSERS_PATH === "/ms-playwright" && existsSync("/app/dist/cli.js");
}

function responseIsWritable(response) {
  return !response.destroyed && !response.writableEnded && !response.writableFinished;
}

function responseHasPendingWork(response) {
  return !response.writableEnded && !response.writableFinished;
}

function send(response, status, payload) {
  if (!responseIsWritable(response)) return false;
  try {
    const body = Buffer.from(JSON.stringify(payload));
    response.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Length": body.length,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    response.end(body);
    return true;
  } catch {
    return false;
  }
}

async function readJson(request, signal) {
  const read = (async () => {
    const chunks = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) throw new Error("body too large");
      chunks.push(chunk);
    }
    const value = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new Error("body is invalid");
    }
    return value;
  })();
  if (!signal) return read;
  if (signal.aborted) throw new Error("request disconnected");
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(new Error("request disconnected"));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([read, aborted]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}

function siteUrl(value) {
  if (Object.keys(value).join() !== "site_url") throw new Error("body is invalid");
  const siteUrl = new URL(value.site_url);
  if (!['http:', 'https:'].includes(siteUrl.protocol) || siteUrl.username || siteUrl.password) {
    throw new Error("URL is invalid");
  }
  return siteUrl.toString();
}

function killAuditProcess(child) {
  if (child.exitCode !== null || child.signalCode !== null) return;
  if (process.platform === "linux" && child.pid) {
    try {
      process.kill(-child.pid, "SIGKILL");
      return;
    } catch {
      // Fall back to the direct child if the process group is unavailable.
    }
  }
  try {
    child.kill("SIGKILL");
  } catch {
    // The exit event still settles the audit when the process raced the kill.
  }
}

function runAudit(siteUrl, outputPath, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error("audit cancelled"));
      return;
    }
    const child = spawn("node", ["/app/extella_entrypoint.mjs", siteUrl, outputPath], {
      cwd: kind === "CrawlSEO" ? "/app" : "/work",
      env: process.env,
      stdio: "ignore",
      detached: process.platform === "linux",
    });
    let settled = false;
    let terminated = false;
    let timer;
    const terminate = () => {
      if (settled || terminated) return;
      terminated = true;
      killAuditProcess(child);
    };
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", terminate);
      error ? reject(error) : resolve();
    };
    child.once("error", finish);
    child.once("exit", (code, signal) => {
      finish(code === 0 && signal === null ? null : new Error("audit failed"));
    });
    signal?.addEventListener("abort", terminate, { once: true });
    timer = setTimeout(terminate, AUDIT_TIMEOUT_MS);
    if (signal?.aborted) terminate();
  });
}

async function audit(siteUrl, signal) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "extella-seo-"));
  const outputPath = path.join(directory, "report.json");
  try {
    await runAudit(siteUrl, outputPath, signal);
    const raw = await readFile(outputPath);
    if (raw.length > MAX_REPORT_BYTES) throw new Error("report too large");
    const payload = JSON.parse(raw.toString("utf8"));
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new Error("report invalid");
    return payload;
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

function watchDisconnect(request, response, controller) {
  const onDisconnect = () => {
    if (responseHasPendingWork(response)) controller.abort();
  };
  request.once("aborted", onDisconnect);
  request.once("error", onDisconnect);
  response.once("close", onDisconnect);
  response.once("error", onDisconnect);
  return () => {
    request.removeListener("aborted", onDisconnect);
    request.removeListener("error", onDisconnect);
    response.removeListener("close", onDisconnect);
    response.removeListener("error", onDisconnect);
  };
}

async function handleRequest(request, response) {
  if (request.method === "GET" && request.url === "/health") {
    const ready = isReady();
    send(response, ready ? 200 : 503, { status: ready ? "ok" : "not_ready", source: kind, ready });
    return;
  }
  if (request.method === "POST" && request.url === "/resolve") {
    try {
      const body = await readJson(request);
      if (
        Object.keys(body).join() !== "hostname"
        || typeof body.hostname !== "string"
        || !/^[A-Za-z0-9.-]{1,253}$/.test(body.hostname)
      ) {
        throw new Error("hostname is invalid");
      }
      const addresses = [...new Set((await lookup(body.hostname, { all: true, verbatim: true })).map(item => item.address))];
      send(response, 200, { addresses });
    } catch {
      send(response, 400, { status: "error", code: "resolve_failed" });
    }
    return;
  }
  if (kind === "Resolver") {
    send(response, 404, { status: "error", code: "route_not_found" });
    return;
  }
  if (request.method !== "POST" || request.url !== "/run") {
    send(response, 404, { status: "error", code: "route_not_found" });
    return;
  }
  if (busy) {
    send(response, 409, { status: "error", code: "worker_busy" });
    return;
  }
  busy = true;
  const controller = new AbortController();
  const stopWatching = watchDisconnect(request, response, controller);
  try {
    const result = await audit(siteUrl(await readJson(request, controller.signal)), controller.signal);
    if (!controller.signal.aborted) send(response, 200, result);
  } catch {
    if (!controller.signal.aborted) send(response, 400, { status: "error", code: "audit_failed" });
  } finally {
    stopWatching();
    busy = false;
  }
}

const server = createServer((request, response) => {
  request.once("error", () => {});
  response.once("error", () => {});
  void handleRequest(request, response).catch(() => {
    send(response, 500, { status: "error", code: "worker_failed" });
  });
});
server.headersTimeout = 5_000;
server.requestTimeout = 10_000;
server.keepAliveTimeout = 5_000;
server.listen(port, "0.0.0.0");
