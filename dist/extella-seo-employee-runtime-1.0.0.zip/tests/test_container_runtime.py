from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT / "experts"))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PROXY = load("extella_source_proxy", ROOT / "runtime" / "source_proxy.py")
SERVER = load("extella_product_server", ROOT / "runtime" / "product" / "server.py")
BOOTSTRAP = load("extella_product_bootstrap", ROOT / "runtime" / "product" / "bootstrap.py")
GATEWAY = load("extella_product_gateway", ROOT / "runtime" / "product" / "gateway.py")
PREPARE = load("extella_deploy_prepare", ROOT / "deploy" / "prepare.py")


class _SourceStub(BaseHTTPRequestHandler):
    received: dict[str, object] = {}

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        type(self).received = json.loads(self.rfile.read(length))
        payload = (
            {"addresses": ["93.184.216.34"]}
            if self.path == "/resolve"
            else {"crawl": {"pagesFound": 1}, "issues": []}
        )
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format: str, *_args: object) -> None:
        return


class ContainerRuntimeTest(unittest.TestCase):
    def test_source_proxy_calls_internal_worker_and_writes_atomically(self) -> None:
        server = ThreadingHTTPServer(("127.0.0.1", 0), _SourceStub)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "crawlseo.json"
                with mock.patch.dict(
                    PROXY.ENDPOINTS,
                    {"CrawlSEO": f"http://127.0.0.1:{server.server_port}/run"},
                ):
                    PROXY.proxy_source("CrawlSEO", "https://example.com/", output)
                self.assertEqual(_SourceStub.received, {"site_url": "https://example.com/"})
                self.assertEqual(json.loads(output.read_text(encoding="utf-8"))["crawl"]["pagesFound"], 1)
                self.assertEqual(list(output.parent.glob("*.tmp")), [])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_worker_dns_result_still_passes_public_address_validation(self) -> None:
        service = __import__("seo_employee_service")
        with mock.patch("urllib.request.urlopen") as open_url:
            response = mock.MagicMock()
            response.__enter__.return_value = response
            response.read.return_value = b'{"addresses":["93.184.216.34"]}'
            open_url.return_value = response
            resolved = service._worker_resolver(
                "example.com", None, type=1, endpoint="http://dns-resolver:8083/resolve"
            )
        self.assertEqual(resolved[0][4][0], "93.184.216.34")
        for endpoint in ("http://crawlseo:8081/resolve", "http://dns-resolver:8084/resolve"):
            with self.subTest(endpoint=endpoint), self.assertRaises(OSError):
                service._worker_resolver("example.com", None, type=1, endpoint=endpoint)

    def test_product_dispatch_is_fixed_and_token_is_required(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            token_file = Path(directory) / "token"
            token_file.write_text("short", encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "too short"):
                SERVER.read_token(token_file)

        with mock.patch.object(SERVER, "seo_employee_state", return_value='{"state":"ready"}'):
            self.assertEqual(SERVER.dispatch("GET", "/api/state", {}), (200, {"state": "ready"}))
        with mock.patch.object(
            SERVER,
            "seo_employee_run",
            return_value='{"status":"success","state":"ready"}',
        ) as run:
            status, payload = SERVER.dispatch("POST", "/api/run", {"site_url": "https://example.com/"})
        self.assertEqual((status, payload["state"]), (200, "ready"))
        self.assertEqual(run.call_args.kwargs["trigger"], "manual")
        self.assertEqual(SERVER.dispatch("POST", "/api/run", {"prompt": "ignored"})[0], 404)

        with tempfile.TemporaryDirectory() as directory:
            secret = Path(directory) / "secret"
            secret.write_text("x" * 32 + "\n", encoding="utf-8")
            self.assertEqual(BOOTSTRAP.read_secret(secret, 32), "x" * 32)

    def test_prepare_accepts_the_documented_sixteen_character_agent_token(self) -> None:
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(
            PREPARE, "SECRETS", Path(directory)
        ):
            token = Path(directory) / "agent_zero_api_key"
            token.write_text("a" * 16 + "\n", encoding="utf-8")
            PREPARE.ensure_generated_secret("agent_zero_api_key", 16)
            self.assertEqual(token.read_text(encoding="utf-8").strip(), "a" * 16)

    def test_compose_isolates_egress_and_enforces_runtime_limits(self) -> None:
        compose = (ROOT / "deploy" / "compose.yaml").read_text(encoding="utf-8")
        product = compose.split("\n  api-gateway:", 1)[0]
        self.assertNotIn("\n    ports:", product)
        self.assertIn("networks: [control, crawlseo_control, resolver_control, seomator_control]", product)
        self.assertIn("EXTELLA_DNS_RESOLVER_URL: http://dns-resolver:8083/resolve", product)
        self.assertIn("dns-resolver:\n        condition: service_healthy", product)
        self.assertIn("- ./bindings:/run/bindings:ro", product)
        self.assertIn("EXTELLA_DEVICE_BINDING_FILE: /run/bindings/device_binding.json", product)
        self.assertIn("EXTELLA_AGENT_BINDING_FILE: /run/bindings/agent_binding.json", product)
        self.assertIn("EXTELLA_AGENT_ZERO_NO_TOOLS_PROFILE: seo_employee_no_tools", product)
        self.assertIn(
            "EXTELLA_AGENT_ZERO_NO_TOOLS_ASSERTION_FILE: /run/bindings/agent_zero_no_tools_profile.json",
            product,
        )
        self.assertIn("healthcheck:", product)
        self.assertIn("http://127.0.0.1:8080/health", product)
        self.assertIn("start_period: 10s", product)
        self.assertIn('"127.0.0.1:${SEO_EMPLOYEE_PORT:-8088}:8080"', compose)
        self.assertNotIn("docker.sock", compose)
        self.assertNotIn("egress", product)
        self.assertIn("networks: [control, agent_zero_egress]", compose)
        self.assertIn("networks: [crawlseo_control, crawlseo_db, crawlseo_egress]", compose)
        resolver = compose.split("\n  dns-resolver:\n", 1)[1].split("\n  seomator:\n", 1)[0]
        self.assertIn("image: extella-seo-crawlseo:1.0.0", resolver)
        self.assertIn("entrypoint: [node, /app/extella_worker_server.mjs]", resolver)
        self.assertIn("EXTELLA_WORKER_KIND: Resolver", resolver)
        self.assertIn("EXTELLA_WORKER_PORT: 8083", resolver)
        self.assertIn("networks: [resolver_control, resolver_egress]", resolver)
        self.assertIn("read_only: true", resolver)
        self.assertIn("cap_drop: [ALL]", resolver)
        self.assertIn("security_opt: [no-new-privileges:true]", resolver)
        self.assertIn('cpus: "0.10"', resolver)
        self.assertIn("mem_limit: 64m", resolver)
        self.assertIn("pids_limit: 32", resolver)
        self.assertIn("logging: *container_logging", resolver)
        self.assertIn("http://127.0.0.1:8083/health", resolver)
        self.assertNotIn("ports:", resolver)
        self.assertNotIn("secrets:", resolver)
        self.assertNotIn("volumes:", resolver)
        self.assertIn("resolver_control:\n    internal: true", compose)
        self.assertIn("resolver_egress: {}", compose)
        self.assertIn("networks: [seomator_control, seomator_egress]", compose)
        self.assertNotIn("\n  egress:", compose)
        self.assertIn("cpus:", compose)
        self.assertIn("mem_limit:", compose)
        self.assertIn("pids_limit:", compose)
        self.assertIn("max-size: \"10m\"", compose)
        self.assertIn("max-file: \"3\"", compose)
        self.assertNotIn("fetch('http://127.0.0.1:8081/health')", compose)
        self.assertNotIn("fetch('http://127.0.0.1:8082/health')", compose)
        self.assertEqual(
            GATEWAY.validate_upstream("agent-zero", "http://host.docker.internal:50081"),
            "http://host.docker.internal:50081",
        )
        with self.assertRaisesRegex(ValueError, "upstream"):
            GATEWAY.validate_upstream("agent-zero", "https://example.com")

    def test_worker_images_preload_the_safe_fetch_guard(self) -> None:
        safe_fetch = (ROOT / "runtime" / "safe_fetch.mjs").read_text(encoding="utf-8")
        self.assertIn("createSafeFetch", safe_fetch)
        self.assertIn("DNS result is not entirely public", safe_fetch)
        self.assertIn("redirect limit exceeded", safe_fetch)
        for name in ("crawlseo", "seomator"):
            dockerfile = (ROOT / "runtime" / name / "Dockerfile").read_text(encoding="utf-8")
            self.assertIn("COPY extella_safe_fetch.mjs /app/extella_safe_fetch.mjs", dockerfile)
            self.assertIn("EXTELLA_SAFE_FETCH_PRELOAD=1", dockerfile)
            self.assertIn("NODE_OPTIONS=--import=/app/extella_safe_fetch.mjs", dockerfile)

    def test_worker_server_keeps_resolver_dns_only(self) -> None:
        worker_server = (ROOT / "runtime" / "worker_server.mjs").read_text(encoding="utf-8")
        self.assertIn("['CrawlSEO', 'SEOmator', 'Resolver']", worker_server)
        self.assertIn('if (kind === "Resolver") return true;', worker_server)
        self.assertIn('if (kind === "Resolver") {\n    send(response, 404, { status: "error", code: "route_not_found" });', worker_server)

    def test_worker_server_cancels_audit_process_group_on_disconnect(self) -> None:
        worker_server = (ROOT / "runtime" / "worker_server.mjs").read_text(encoding="utf-8")
        self.assertIn('detached: process.platform === "linux"', worker_server)
        self.assertIn('process.kill(-child.pid, "SIGKILL")', worker_server)
        self.assertIn('child.kill("SIGKILL")', worker_server)
        self.assertIn('controller.abort()', worker_server)
        self.assertNotIn('request.once("close", onDisconnect)', worker_server)
        self.assertIn('signal?.removeEventListener("abort", terminate)', worker_server)
        self.assertIn('if (!controller.signal.aborted) send(response, 200, result);', worker_server)
        self.assertIn('if (!responseIsWritable(response)) return false;', worker_server)
        self.assertIn('void handleRequest(request, response).catch(() => {', worker_server)


if __name__ == "__main__":
    unittest.main()
