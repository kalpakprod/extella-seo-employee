import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import vm from 'node:vm';

const appRoot = new URL('../../app/', import.meta.url);
const [html, css, app, bridgeSource] = await Promise.all([
  readFile(new URL('index.html', appRoot), 'utf8'),
  readFile(new URL('styles.css', appRoot), 'utf8'),
  readFile(new URL('app.js', appRoot), 'utf8'),
  readFile(new URL('extella-bridge.js', appRoot), 'utf8'),
]);
const all = [html, css, app, bridgeSource].join('\n');
const bridgeModule = { exports: {} };
vm.runInNewContext(bridgeSource, { module: bridgeModule, exports: bridgeModule.exports });
const { unwrapExtellaResult } = bridgeModule.exports;
const appModule = { exports: {} };
vm.runInNewContext(app, { module: appModule, exports: appModule.exports });
const { buildReportModel, nextRunFrom, runControlState } = appModule.exports;

function expectAll(source, values, message) {
  values.forEach(value => assert.ok(source.includes(value), `${message}: ${value}`));
}

test('[UC-SEO-001] first screen names product, outcome, and first step', () => {
  expectAll(html, ['SEO-сотрудник', 'задачи с доказательствами', 'начни с первой проверки'], 'orientation copy missing');
});

test('[UC-SEO-002] there is one bronze primary action with both locale labels', () => {
  assert.equal((html.match(/class="primary"/g) || []).length, 1);
  assert.match(html, />Проверить сайт<\/button>/);
  assert.match(app, /runAction: 'Check site'/);
});

test('[UC-SEO-003] settings contain validated URL, daily time, and IANA timezone', () => {
  expectAll(html, ['name="site_url"', 'name="daily_run_time"', 'name="timezone"'], 'setting missing');
  expectAll(app, ['publicUrl(', 'validTimezone(', "t('invalidUrl')", "t('invalidTimezone')"], 'validation hook missing');
});

test('[UC-SEO-004] empty representation explains the first check', () => {
  expectAll(html, ['data-state-view="empty"', 'Проверок ещё нет', 'Проверить сайт'], 'empty state incomplete');
});

test('[UC-SEO-005] running representation locks before the call and unlocks in finally', () => {
  assert.ok(html.includes('data-state-view="running"'));
  const run = app.slice(app.indexOf('async function runAudit'), app.indexOf('async function loadState'));
  assert.ok(run.indexOf('setRunBusy(true)') < run.indexOf('await bridge.run'), 'busy state must start before bridge call');
  assert.match(run, /finally\s*\{\s*setRunBusy\(false\)/);
  assert.match(app, /runBusy \|\| currentState\.state === 'running'/);
  assert.match(html, /id="running-stage"/);
});

test('[UC-SEO-006] failed representation gives friendly guidance without raw errors', () => {
  expectAll(html, ['data-state-view="failed"', 'Проверь публичный адрес и подключение'], 'failed state incomplete');
  assert.match(app, /function friendlyError/);
  assert.doesNotMatch(app, /failed-reason'\)\.textContent\s*=\s*state\.last_error/);
});

test('[UC-SEO-007] ready result shows run time, sources, comparison, and caps tasks', () => {
  expectAll(html, ['id="run-time"', 'id="source-list"', 'comparison-grid'], 'ready result hook missing');
});

test('[UC-SEO-008] partial shares result representation and lists missing sources', () => {
  assert.equal((html.match(/data-state-view="result"/g) || []).length, 1);
  expectAll(app, ["stateName === 'ready' || stateName === 'partial'", "stateName === 'partial'", 'report.missing_data'], 'partial behavior missing');
  assert.match(app, /!\['ok', 'not_configured'\]\.includes\(source\.status\)/);
});

test('report model hydrates comparison stubs from full tasks by task_id', () => {
  const evidence = [{ source: 'CrawlSEO', rule: 'meta-description', fact: 'missing' }];
  const fullTask = {
    task_id: 'task-new', url: 'https://example.com/', rule_key: 'meta-description-missing', severity: 'error',
    confirmed_fact: 'The meta description is missing.', sources: ['CrawlSEO', 'SEOmator'],
    business_impact: 'Search snippets have no summary.', minimal_fix: 'Add a concise description.',
    verification: 'Run the audit again.', evidence,
  };
  const model = buildReportModel({
    tasks: [fullTask],
    comparison: {
      new: 1, new_items: [{ task_id: 'task-new', url: 'stub-url' }],
      fixed: 1, fixed_items: [{ task_id: 'task-fixed', url: 'https://example.com/old' }],
      unchanged: 0, unchanged_items: [],
    },
  });
  assert.equal(model.groups.new[0].url, fullTask.url);
  assert.equal(model.groups.new[0].business_impact, fullTask.business_impact);
  assert.deepEqual(model.groups.new[0].evidence, evidence);
  assert.equal(model.groups.fixed[0].task_id, 'task-fixed');
  assert.equal(model.counts.new, 1);
  assert.equal(model.counts.fixed, 1);
  const capped = buildReportModel({
    tasks: Array.from({ length: 11 }, (_, index) => ({ task_id: `task-${index}`, comparison_group: 'new' })),
  });
  assert.equal(capped.groups.new.length, 10);
});

test('next run uses the backend schedules[].next_run field, including null', () => {
  const expected = '2026-08-30T09:00:00+00:00';
  assert.equal(nextRunFrom({ schedules: [{ id: 'daily', active: true, next_run: expected }] }), expected);
  assert.equal(nextRunFrom({ schedules: [{ id: 'daily', active: true, next_run: null }], next_run_at: expected }), null);
});

test('duplicate and running run responses are control states, not failures', () => {
  assert.equal(runControlState({ status: 'success', state: 'duplicate', duplicate: true }), 'duplicate');
  assert.equal(runControlState({ status: 'success', state: 'running' }), 'running');
  assert.equal(runControlState({ status: 'success', state: 'ready' }), null);
});

test('[UC-SEO-009] every task card renders all required fields', () => {
  expectAll(app, ["t('severity')", "t('url')", "t('fact')", "t('sources')", "t('businessImpact')", "t('minimalFix')", "t('verification')"], 'task field missing');
});

test('[UC-SEO-010] evidence is independently expandable for every capped task', () => {
  expectAll(app, ["document.createElement('details')", "textNode('summary'", 'EVIDENCE_TEST_IDS', "item?.source"], 'evidence hook missing');
  assert.equal(new Set([...app.matchAll(/'([a-z]+)'/g)].map(match => match[1])).size > 0, true);
});

test('[UC-SEO-011] new, fixed, and unchanged groups accept empty results', () => {
  expectAll(html, ['id="new-findings"', 'id="fixed-findings"', 'id="unchanged-findings"'], 'comparison group missing');
  expectAll(app, ["const GROUPS = ['new', 'fixed', 'unchanged']", "t('emptyGroup')"], 'empty comparison behavior missing');
});

test('[UC-SEO-012] daily schedule shows time, timezone, and next run', () => {
  expectAll(html, ['id="schedule-time"', 'id="next-run"'], 'schedule output missing');
  expectAll(app, ['daily_run_time', 'timezone', 'next_run_at'], 'schedule field missing');
});

test('[UC-SEO-013] manual run keeps its trigger and has no polling or self-repeat', () => {
  assert.match(app, /method: 'run', \.\.\.settings, trigger: 'manual'/);
  assert.doesNotMatch(all, /setInterval\s*\(|requestAnimationFrame\s*\(/);
  assert.equal((app.match(/await bridge\.run\(EXPERT_RUN/g) || []).length, 2, 'only configure and one manual run may invoke the runner');
});

test('[UC-SEO-014] help explains sources, limits, and rollback owner', () => {
  expectAll(html, ['data-testid="help-toggle"', 'не гарантирует позиции, трафик или выручку', 'как откатить изменение'], 'help boundary missing');
});

test('[UC-SEO-015] panel exposes no publish, index, site-change, or link-buy actions', () => {
  const buttonText = [...html.matchAll(/<button\b[^>]*>([^<]+)<\/button>/g)].map(match => match[1].trim()).join(' ');
  assert.doesNotMatch(buttonText, /публи|индекс|измен|ссыл|publish|index|change|link/i);
});

test('[UC-SEO-016] Search Console is optional and has no dead connect button', () => {
  assert.match(html, /Google Search Console[\s\S]*Не настроена, необязательно/);
  assert.doesNotMatch(html, /<button\b[^>]*>[^<]*(Подключ|Connect)/i);
});

test('[UC-SEO-017] RU and EN copy comes from etb_init', () => {
  expectAll(app, ['ru: {', 'en: {', "data.type === 'etb_init'", 'data.language || data.lang || data.locale'], 'host language hook missing');
});

test('[UC-SEO-018] theme comes from etb_init and etb_theme with no local switch', () => {
  expectAll(bridgeSource, ["data.type === 'etb_init'", "data.type === 'etb_theme'"], 'host theme message missing');
  expectAll(app, ["setAttribute('data-lm', '1')", "removeAttribute('data-lm')"], 'theme application missing');
  assert.doesNotMatch(html, /theme-(switch|toggle)|language-(switch|toggle)/i);
});

test('[UC-SEO-019] status is announced and every interactive control has a stable test id', () => {
  assert.match(html, /aria-live="polite"/);
  assert.match(css, /:focus-visible/);
  const controls = [...html.matchAll(/<(button|input|select|textarea|summary)\b[^>]*>/g)].map(match => match[0]);
  const ids = controls.map(control => control.match(/data-testid="([^"]+)"/)?.[1]);
  assert.ok(ids.every(Boolean), 'every static interactive control needs data-testid');
  assert.equal(new Set(ids).size, ids.length, 'static data-testid values must be unique');
  assert.ok(ids.every(id => !/\d/.test(id)), 'data-testid values must not contain digits');
  assert.match(app, /summary\.dataset\.testid = `evidence-\$\{EVIDENCE_TEST_IDS\[index\]\}`/);
});

test('[UC-SEO-020] Extella design tokens, waiting state, responsiveness, and reduced motion remain', () => {
  expectAll(css, ['#FAF9F5', '#FFFFFF', '#F5F3EC', '#0A0A0A', '#C57E33', '#2F6B66', '#D7E0DC', 'Source Serif 4', 'JetBrains Mono', 'Nunito'], 'design token missing');
  expectAll(css, ['@media (min-width: 1400px)', '@media (max-width: 560px)', 'prefers-reduced-motion', 'overflow-x: hidden'], 'responsive/accessibility hook missing');
  assert.equal((css.match(/background:\s*var\(--accent\)/g) || []).length, 1, 'bronze is reserved for the primary action');
});

test('[UC-SEO-021] data disclosure precedes any unavailable Search Console connection', () => {
  expectAll(html, ['data-testid="data-toggle"', 'Категории:', 'Выполнение и хранение:', 'Получатель входа модели:', 'Срок:', 'Удаление:', 'явного согласия'], 'data disclosure missing');
});

test('[H72] bridge unwraps both transport envelopes and parses expert JSON strings', () => {
  const plain = value => JSON.parse(JSON.stringify(value));
  const domain = { status: 'success', state: 'ready', last_report: { state: 'ready' } };
  const wrapped = {
    status: 'ok', agent_id: 'agent', result: {
      status: 'success', expert_name: 'seo_employee_state', result: JSON.stringify(domain),
    },
  };
  assert.deepEqual(plain(unwrapExtellaResult(wrapped)), domain);
  assert.deepEqual(plain(unwrapExtellaResult({ status: 'ok', agent_id: 'agent', res: JSON.stringify(domain) })), domain);
  assert.deepEqual(plain(unwrapExtellaResult({ ok: true, res: null, result: JSON.stringify(domain) })), domain);
  assert.deepEqual(plain(unwrapExtellaResult({ result: JSON.stringify(domain) })), domain);
  assert.deepEqual(plain(unwrapExtellaResult({ type: 'etb_expert_result', reqId: 'req', ok: true, res: domain })), domain);
  assert.deepEqual(plain(unwrapExtellaResult(JSON.stringify(domain))), domain);
  assert.deepEqual(plain(unwrapExtellaResult({ status: 'success', result: { domain: true } })),
    { status: 'success', result: { domain: true } }, 'domain result must not be mistaken for transport');
  assert.throws(() => unwrapExtellaResult("{'state': 'ready'}"), /нельзя прочитать/);
});

test('bridge settles responses and timeouts without pending requests', async () => {
  const sent = [];
  const parent = { postMessage: message => sent.push(message) };
  let onMessage;
  const fakeWindow = {
    parent,
    addEventListener: (type, listener) => { if (type === 'message') onMessage = listener; },
    setTimeout,
    clearTimeout,
  };
  const runtimeModule = { exports: {} };
  vm.runInNewContext(bridgeSource, {
    module: runtimeModule,
    exports: runtimeModule.exports,
    window: fakeWindow,
    crypto: { getRandomValues: values => { values[0] = 1; return values; } },
  });
  const bridge = new runtimeModule.exports.ExtellaBridge({ allowedExperts: ['seo_employee_state'] });
  onMessage({ source: parent, data: { type: 'etb_init', device: 'device-160' } });
  const responsePromise = bridge.run('seo_employee_state');
  const reqId = sent.at(-1).reqId;
  assert.equal(sent.at(-1).target, 'device-160');
  onMessage({ source: parent, data: {
    type: 'etb_expert_result', reqId, ok: true, res: JSON.stringify({ status: 'success', state: 'empty' }),
  } });
  assert.deepEqual(JSON.parse(JSON.stringify(await responsePromise)), { ok: true, data: { status: 'success', state: 'empty' } });
  assert.equal(bridge.pending.size, 0);
  const timeout = await bridge.run('seo_employee_state', {}, { timeoutMs: 1 });
  assert.equal(timeout.ok, false);
  assert.equal(bridge.pending.size, 0);
});

test('[H65] panel self-heals stale cache before creating the bridge', () => {
  const boot = app.slice(app.indexOf('async function boot'));
  assert.match(app, /const PANEL_VERSION='1\.0\.0'/);
  assert.match(app, /fetch\(window\.location\.pathname, \{ cache: 'no-store', signal: controller\.signal \}\)/);
  assert.match(app, /controller\.abort\(\), 3000/);
  assert.ok(boot.indexOf('await healStaleCache()') < boot.indexOf('new ExtellaBridge'), 'cache check must run first');
  assert.equal((all.match(/\bfetch\s*\(/g) || []).length, 1, 'only same-page cache healing may use fetch');
});

test('bridge has a finite timeout and only the two contracted expert routes', () => {
  expectAll(bridgeSource, ["type:'etb_run_expert'", 'etb_expert_result', 'event.source !== window.parent', 'window.setTimeout'], 'bridge guard missing');
  assert.match(app, /allowedExperts: \[EXPERT_RUN, EXPERT_STATE\]/);
  assert.deepEqual([...all.matchAll(/'seo_employee_(?:run|state)'/g)].map(match => match[0]).sort(),
    ["'seo_employee_run'", "'seo_employee_state'"], 'unexpected expert route found');
  assert.doesNotMatch(all, /https?:\/\/(?:localhost|127\.|10\.|192\.168\.)/i);
});

test('literal DOM references resolve and markup ids stay unique', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
  assert.equal(new Set(ids).size, ids.length, 'markup ids must be unique');
  const referenced = [...app.matchAll(/\bel\('([^']+)'\)/g)].map(match => match[1]);
  const missing = [...new Set(referenced)].filter(id => !ids.includes(id));
  assert.deepEqual(missing, []);
});
