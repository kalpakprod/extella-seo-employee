import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import process from "node:process";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { PrismaClient } from "@prisma/client";

const [siteUrl, outputPath] = process.argv.slice(2);
if (!siteUrl || !outputPath) {
  throw new Error("usage: crawlseo_once.mjs <public-url> <output-path>");
}

const parsedUrl = new URL(siteUrl);
if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
  throw new Error("site URL must use http or https");
}
parsedUrl.hash = "";
const normalizedSiteUrl = parsedUrl.toString();
const siteHash = createHash("sha256").update(normalizedSiteUrl).digest("hex").slice(0, 16);
const siteId = `extella-${siteHash}`;
const prisma = new PrismaClient();
const transport = new StdioClientTransport({
  command: "node",
  args: [process.env.TSX_CLI || "node_modules/tsx/dist/cli.mjs", "mcp/server.ts"],
  cwd: process.cwd(),
  env: process.env,
  stderr: "pipe",
});
const client = new Client({ name: "extella-seo-employee", version: "1.0.0" });

async function writeJsonAtomic(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.tmp`;
  await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(temporary, filePath);
}

try {
  await prisma.user.upsert({
    where: { email: "seo-employee-local.invalid" },
    create: {
      id: "extella-seo-employee",
      email: "seo-employee-local.invalid",
      name: "Extella SEO Employee",
    },
    update: {},
  });
  await prisma.site.upsert({
    where: { id: siteId },
    create: { id: siteId, userId: "extella-seo-employee", domain: normalizedSiteUrl },
    update: { domain: normalizedSiteUrl },
  });

  await client.connect(transport);
  const result = await client.callTool({
    name: "run_crawl",
    arguments: { siteId, maxPages: 1 },
  });
  if (result.isError) throw new Error("CrawlSEO run_crawl returned an error");

  const text = result.content
    .filter((item) => item.type === "text")
    .map((item) => item.text)
    .join("\n");
  const crawlId = text.match(/Crawl ID:\s*([^\s]+)/)?.[1];
  if (!crawlId) throw new Error("CrawlSEO run_crawl did not return a crawl ID");

  const deadline = Date.now() + 120_000;
  let crawl;
  while (Date.now() < deadline) {
    crawl = await prisma.crawl.findUnique({
      where: { id: crawlId },
      select: {
        id: true,
        status: true,
        startedAt: true,
        finishedAt: true,
        pagesFound: true,
        issuesFound: true,
        healthScore: true,
        maxPages: true,
      },
    });
    if (crawl?.status === "COMPLETED" || crawl?.status === "FAILED") break;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  if (!crawl || crawl.status !== "COMPLETED") {
    throw new Error(`CrawlSEO crawl did not complete: ${crawl?.status ?? "missing"}`);
  }
  if (crawl.maxPages !== 1 || crawl.pagesFound !== 1) {
    throw new Error(
      `CrawlSEO one-page cap violated: maxPages=${crawl.maxPages}, pagesFound=${crawl.pagesFound}`,
    );
  }

  const issues = await prisma.crawlIssue.findMany({
    where: { crawlId },
    orderBy: [{ type: "asc" }, { severity: "asc" }, { url: "asc" }, { message: "asc" }],
    select: { type: true, severity: true, url: true, message: true },
  });
  await writeJsonAtomic(outputPath, {
    schema: "extella.crawlseo_source.v1",
    source: "CrawlSEO",
    source_commit: "8683b2740eca5059faa0949c2175a7548216bd50",
    tool: "run_crawl",
    tool_calls: 1,
    requested_max_pages: 1,
    site_id: siteId,
    site_url: normalizedSiteUrl,
    crawl,
    issues,
  });
  console.log(JSON.stringify({ crawlId, maxPages: 1, pagesFound: 1, issuesFound: issues.length }));
} finally {
  await client.close().catch(() => {});
  await prisma.$disconnect();
}
